/*************************
 *
 * TodoItem.h
 *
 *  class definition for todo items.
 *  inherits class OutlineItem
 *
 *  This file is part of Prozect.
 *  Copyright (C) 2003 Robert T. Miller
 *  
 *  Prozect is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  Prozect is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with Prozect; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  
 *************************/
#ifndef TODOITEM_H
#define TODOITEM_H

#include "qclic.h"
#include "Outline.h"
#include "OutlineItem.h"

class TodoItem : public OutlineItem {
 public:
  TodoItem(Outline *list, QString &text);
  TodoItem(OutlineItem *parent, QString &text);
  ~TodoItem();

  // only for ToDo item
  void setOnSingle(bool);
  bool updateCheckBox();

  // re-implemented from OutlineItem (access QCheckListItem instead of QListViewItem):

  virtual OutlineItem *mapToOI(QListViewItem *);
  void itemOutput(QTextStream& out);

  // item number access
  virtual int getNumber() const;
  virtual void setNumber(int);
  virtual bool getNumbering();
  virtual void setNumbering(bool);
  virtual QString getNumberFormatted();

  // re-implemented from QListViewItem and/or QCheckListItem

  virtual int depth() const;
  virtual int childCount() const;
  virtual bool isOpen();
  virtual void setOpen(bool);
  virtual bool isOn();
  virtual void setOn(bool);
  virtual bool isSelected();

  virtual OutlineItem *parent();
  virtual OutlineItem * firstChild();
  virtual OutlineItem * nextSibling();
  virtual OutlineItem * itemAbove();
  virtual OutlineItem * itemBelow();

  virtual void insertItem(OutlineItem *);
  virtual void takeItem(OutlineItem*);
  virtual QListViewItem * getItem();
  virtual Outline * listView();

  virtual void sortChildItems(int, bool);
  virtual void setPixmap( int column, const QPixmap & pm );
  virtual QString text(int col=0) const;
  virtual void setText(int, const QString &);
  virtual QString plainText(int c=0) const;


  // public variables
  Qclic *qcli;

 private:
  bool checkState;
  friend QTextStream& operator<<(QTextStream& out, TodoItem* node);
};

#endif
