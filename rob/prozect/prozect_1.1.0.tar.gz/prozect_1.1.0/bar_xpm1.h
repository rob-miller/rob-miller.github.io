/*********************
 * bar_xpm1.h
 *
 * bitmap definitions for progress/completion bars
 * only the colour differs from bar_xpm2.h
 *
 *  This file is part of Prozect.
 *  Copyright (C) 2003 Robert T. Miller
 *  
 *  Prozect is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  Prozect is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with Prozect; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  
 ********************/
#ifndef BAR_XPM1_H
#define BAR_XPM1_H


#define BAR1COL "z	c #00ff00"
 
static const char * bar0a[] = {
  "20 10 4 1",
  "X	c #000000",
  "O	c #ffffff",
  ".	c none",
  BAR1COL,
  "....................",
  "XXXXXXXXXXXXXX......",
  "XXXXXXXXXXXXXX......",
  "XXOOOOOOOOOOXX......",
  "XXOOOOOOOOOOXX......",
  "XXOOOOOOOOOOXX......",
  "XXOOOOOOOOOOXX......",
  "XXXXXXXXXXXXXX......",
  "XXXXXXXXXXXXXX......",
  "...................."
};

static const char * bar1a[] = {
  "20 10 4 1",
  "X	c #000000",
  "O	c #ffffff",
  ".	c none",
  BAR1COL,
  "....................",
  "XXXXXXXXXXXXXX......",
  "XXXXXXXXXXXXXX......",
  "XXzOOOOOOOOOXX......",
  "XXzOOOOOOOOOXX......",
  "XXzOOOOOOOOOXX......",
  "XXzOOOOOOOOOXX......",
  "XXXXXXXXXXXXXX......",
  "XXXXXXXXXXXXXX......",
  "...................."
};

static const char * bar2a[] = {
  "20 10 4 1",
  "X	c #000000",
  "O	c #ffffff",
  ".	c none",
  BAR1COL,
  "....................",
  "XXXXXXXXXXXXXX......",
  "XXXXXXXXXXXXXX......",
  "XXzzOOOOOOOOXX......",
  "XXzzOOOOOOOOXX......",
  "XXzzOOOOOOOOXX......",
  "XXzzOOOOOOOOXX......",
  "XXXXXXXXXXXXXX......",
  "XXXXXXXXXXXXXX......",
  "...................."
};

static const char * bar3a[] = {
  "20 10 4 1",
  "X	c #000000",
  "O	c #ffffff",
  ".	c none",
  BAR1COL,
  "....................",
  "XXXXXXXXXXXXXX......",
  "XXXXXXXXXXXXXX......",
  "XXzzzOOOOOOOXX......",
  "XXzzzOOOOOOOXX......",
  "XXzzzOOOOOOOXX......",
  "XXzzzOOOOOOOXX......",
  "XXXXXXXXXXXXXX......",
  "XXXXXXXXXXXXXX......",
  "...................."
};

static const char * bar4a[] = {
  "20 10 4 1",
  "X	c #000000",
  "O	c #ffffff",
  ".	c none",
  BAR1COL,
  "....................",
  "XXXXXXXXXXXXXX......",
  "XXXXXXXXXXXXXX......",
  "XXzzzzOOOOOOXX......",
  "XXzzzzOOOOOOXX......",
  "XXzzzzOOOOOOXX......",
  "XXzzzzOOOOOOXX......",
  "XXXXXXXXXXXXXX......",
  "XXXXXXXXXXXXXX......",
  "...................."
};

static const char * bar5a[] = {
  "20 10 4 1",
  "X	c #000000",
  "O	c #ffffff",
  ".	c none",
  BAR1COL,
  "....................",
  "XXXXXXXXXXXXXX......",
  "XXXXXXXXXXXXXX......",
  "XXzzzzzOOOOOXX......",
  "XXzzzzzOOOOOXX......",
  "XXzzzzzOOOOOXX......",
  "XXzzzzzOOOOOXX......",
  "XXXXXXXXXXXXXX......",
  "XXXXXXXXXXXXXX......",
  "...................."
};

static const char * bar6a[] = {
  "20 10 4 1",
  "X	c #000000",
  "O	c #ffffff",
  ".	c none",
  BAR1COL,
  "....................",
  "XXXXXXXXXXXXXX......",
  "XXXXXXXXXXXXXX......",
  "XXzzzzzzOOOOXX......",
  "XXzzzzzzOOOOXX......",
  "XXzzzzzzOOOOXX......",
  "XXzzzzzzOOOOXX......",
  "XXXXXXXXXXXXXX......",
  "XXXXXXXXXXXXXX......",
  "...................."
};

static const char * bar7a[] = {
  "20 10 4 1",
  "X	c #000000",
  "O	c #ffffff",
  ".	c none",
  BAR1COL,
  "....................",
  "XXXXXXXXXXXXXX......",
  "XXXXXXXXXXXXXX......",
  "XXzzzzzzzOOOXX......",
  "XXzzzzzzzOOOXX......",
  "XXzzzzzzzOOOXX......",
  "XXzzzzzzzOOOXX......",
  "XXXXXXXXXXXXXX......",
  "XXXXXXXXXXXXXX......",
  "...................."
};

static const char * bar8a[] = {
  "20 10 4 1",
  "X	c #000000",
  "O	c #ffffff",
  ".	c none",
  BAR1COL,
  "....................",
  "XXXXXXXXXXXXXX......",
  "XXXXXXXXXXXXXX......",
  "XXzzzzzzzzOOXX......",
  "XXzzzzzzzzOOXX......",
  "XXzzzzzzzzOOXX......",
  "XXzzzzzzzzOOXX......",
  "XXXXXXXXXXXXXX......",
  "XXXXXXXXXXXXXX......",
  "...................."
};

static const char * bar9a[] = {
  "20 10 4 1",
  "X	c #000000",
  "O	c #ffffff",
  ".	c none",
  BAR1COL,
  "....................",
  "XXXXXXXXXXXXXX......",
  "XXXXXXXXXXXXXX......",
  "XXzzzzzzzzzOXX......",
  "XXzzzzzzzzzOXX......",
  "XXzzzzzzzzzOXX......",
  "XXzzzzzzzzzOXX......",
  "XXXXXXXXXXXXXX......",
  "XXXXXXXXXXXXXX......",
  "...................."
};

static const char * bar10a[] = {
  "20 10 4 1",
  "X	c #000000",
  "O	c #ffffff",
  ".	c none",
  BAR1COL,
  "....................",
  "XXXXXXXXXXXXXX......",
  "XXXXXXXXXXXXXX......",
  "XXzzzzzzzzzzXX......",
  "XXzzzzzzzzzzXX......",
  "XXzzzzzzzzzzXX......",
  "XXzzzzzzzzzzXX......",
  "XXXXXXXXXXXXXX......",
  "XXXXXXXXXXXXXX......",
  "...................."
};


#endif
