/**********************
 *
 * ProgressItem.cpp
 *
 * function implementation for ProgressItem class
 *
 *  This file is part of Prozect.
 *  Copyright (C) 2003 Robert T. Miller
 *  
 *  Prozect is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  Prozect is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with Prozect; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  
 *********************/
#include "Outline.h"
#include "OutlineItem.h"
#include "ProgressItem.h"

#include "debug.h"

ProgressItem::ProgressItem(Outline *list, QString &text) 
  : OutlineItem(list,text, FALSE) {

  rDebug("ProgressItem constructor-o: entry %s",text.latin1());

  qlvi = new Qlvic(list,text,this);  //QListViewItem(list,text);
  list->mapOI[qlvi] = this;

  isOutlineV = isTodoV = isNumericV = false;
  isProgressV = true;

  pmr = new pmResource();
  QPixmap *pm_ref = pmr->getPmA(10);
  qlvi->setPixmap(0,*pm_ref);
  delete pm_ref;
  
  OutlineItem::value=1.0;  // no children, so 100% done
  OutlineItem::denInc=1.0;
}

ProgressItem::ProgressItem(OutlineItem *parent, QString &text) 
  :  OutlineItem(parent,text,FALSE) {

  rDebug("ProgressItem constructor-oi: entry %s",text.latin1());

  qlvi = new Qlvic(parent->qlvi,text,this);  //QListViewItem(list,text);
  Outline *list = (Outline *) qlvi->listView();
  list->mapOI[qlvi] = this;

  isOutlineV = isTodoV = isNumericV = false;
  isProgressV = true;

  pmr = new pmResource();
  QPixmap *pm_ref = pmr->getPmA(10);
  qlvi->setPixmap(0,*pm_ref);
  delete pm_ref;

  OutlineItem::value=1.0;  // no children, so 100% done
  OutlineItem::denInc=1.0;
}

ProgressItem::~ProgressItem() {
  rDebug("pi destructor called %s",this->text().latin1());
  delete pmr;
}

void ProgressItem::itemOutput(QTextStream& out) {
  out << this;
}

// shared with Numeric Item
void ProgressItem::updateBar() {
  OutlineItem *oi = firstChild();
  float num=0.0,den=0.0;

  //rDebug("ub-pi: %s ",text().latin1());
  while (oi) {
    num += oi->getValue();
    den += oi->getDenInc();
    //rDebug("%s: %f / %f",oi->text().latin1(),oi->getValue(),oi->getDenInc());
    oi = oi->nextSibling();
  }
  
  int hoic = hOICount();
  num += float(hoic);
  den += float(hoic);

  if (den>0.0) 
    OutlineItem::value = num/den;
  else OutlineItem::value = 1.0;

  //rDebug("update Progress %f / %f = %f",num,den,OutlineItem::value);

  QPixmap *pm_ref = pmr->getPmFracA(OutlineItem::value);
  qlvi->setPixmap(0,*pm_ref);
  delete pm_ref;

  if (parent()) 
    parent()->updateBar();
}

// private

QTextStream& operator<<(QTextStream &out, ProgressItem* node) {

  //  return out << (OutlineItem*) node;
  
  for (int i = 0; i <= node->depth(); i++) {
    out << '*';
  }
  //out << node->getNumber();

  out << "[]";

  if (node->listView()->sEventDates()) {
    if (node->edate) {
      QDate *d = node->edate;
      out << '{' << d->year() << '/' << d->month() << '/' << d->day()  << '}';
    }
  }

  if (node->ddate) {
    QDate *d = node->ddate;
    out << '<' << d->year() << '/' << d->month() << '/' << d->day()  << '>';
  }

  out << ' ' << node->plainText(0) << '\n';

  for (int i=0; i<node->piBlanks; i++) {
    out << '\n';
  }

  if (node->note)
    out << *(node->note);

  for (int i=0; i<node->pnBlanks; i++) {
    out << '\n';
  }

  return out;
}

