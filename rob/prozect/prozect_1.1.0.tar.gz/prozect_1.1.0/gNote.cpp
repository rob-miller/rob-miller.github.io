/********************
 *
 * gNote.cpp
 *
 *  dialog to obtain note text (QMultiLineEdit class) for any item.
 *
 *  This file is part of Prozect.
 *  Copyright (C) 2003 Robert T. Miller
 *  
 *  Prozect is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  Prozect is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with Prozect; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  
 *******************/
#include "gNote.h"
//#include "debug.h"

getNoteD::getNoteD(QWidget * parent=0, const char * name=0, bool modal=false, WFlags f=0 ) 
  : QDialog(parent, name, modal, f) {
  
  qmle = new QMultiLineEdit(this,"note editor");
  qmle->setWordWrap( QMultiLineEdit::WidgetWidth );

  //rDebug("par max w %d  h %d",parent->size().width(),parent->size().height());

  qmle->resize(238,200);

}

getNoteD::~getNoteD() {
  delete qmle;
}

bool getNoteD::query(const QString &title, QString *initText, QString **rslt) {

  if (initText)
    qmle->setText(*initText);
  else
    qmle->clear();

  qmle->setEdited(false);

  qmle->setFocus();
  
  QString ftitle = "note: ";
  ftitle += title;
  setCaption(ftitle);

  if (exec() && qmle->edited()) {
    //rDebug("getNote returning .%s.",qmle->text().latin1());
    if (*rslt) 
      delete *rslt;

    if (qmle->text().isEmpty()) {
      *rslt = 0;
    } else {
      *rslt = new QString(qmle->text());
    }

    return true;
  } else 
    return false;

}

