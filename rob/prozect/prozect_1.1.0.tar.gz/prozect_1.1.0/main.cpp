/*
 *  Prozect
 *  Copyright (C) 2003 Robert T. Miller
 *
 *  This file is part of Prozect.
 *  
 *  Prozect is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  Prozect is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with Prozect; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  
 *  Prozect was originally based on ZOutline, copyright (C) 2002 Serge Stinkwich
 */

#include <qpe/qpeapplication.h>
#include "prozect.h"

// main program
int main (int argc, char** argv)
{
   QPEApplication a(argc, argv);
   Prozect w;

   a.showMainDocumentWidget(&w);
   if (argc > 1)
     w.setDocument(argv[1]);

   return a.exec();
}
