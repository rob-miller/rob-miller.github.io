/********************
 *
 * gNiNumDen.h
 *
 *  dialog to obtain numerator and denominator values for completion
 *  items.
 *
 *  This file is part of Prozect.
 *  Copyright (C) 2003 Robert T. Miller
 *  
 *  Prozect is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  Prozect is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with Prozect; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  
 *****************/

#ifndef GNINUMDEN_H
#define GNINUMDEN_H

#include <qdialog.h>
#include <qtoolbar.h>
#include <qlineedit.h>


class getNiNumDen : public QDialog {
  Q_OBJECT
 public:
  getNiNumDen( QWidget * parent=0, const char * name=0, bool modal=false, WFlags f=0 );
  ~getNiNumDen();

  bool query(int *num, int*den);

 private:
  QToolBar *gnd_tb;
  QLineEdit *gnd_num_e;
  QLineEdit *gnd_den_e;

 private slots:
   void slotGndNumLErtn();
   void slotGndDenLErtn();
};


#endif
