/**********************
 *
 * NumericItem.cpp
 *
 * function implementation for NumericItem class
 *
 *  This file is part of Prozect.
 *  Copyright (C) 2003 Robert T. Miller
 *  
 *  Prozect is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  Prozect is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with Prozect; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  
 *********************/
#include "NumericItem.h"
#include "Outline.h"
#include "OutlineItem.h"


#include <qlabel.h>
#include <qmessagebox.h>

#include "debug.h"

// constructor call at Outline level
NumericItem::NumericItem(Outline *list, QString &text) 
  : OutlineItem(list,text, FALSE) {

  rDebug("NumericItem constructor-o: entry %s",text.latin1());

  qlvi = new Qlvic(list,text,this);  //QListViewItem(list,text);
  list->mapOI[qlvi] = this;

  OutlineItem::isOutlineV = OutlineItem::isTodoV = OutlineItem::isProgressV = false;
  OutlineItem::isNumericV = true;

  numerator=0;
  denominator=10;
  OutlineItem::denInc=1.0;
  OutlineItem::value=0.0;

  pmr = new pmResource();
  QPixmap *pm_ref = pmr->getPmB(0);
  qlvi->setPixmap(0,*pm_ref);
  delete pm_ref;

}

// constructor call at OutlineItem level
NumericItem::NumericItem(OutlineItem *parent, QString &text) 
  :  OutlineItem(parent,text,FALSE) {

  rDebug("NumericItem constructor-oi: entry %s",text.latin1());

  qlvi = new Qlvic(parent->qlvi,text,this);  //QListViewItem(list,text);
  Outline *list = (Outline *) qlvi->listView();
  list->mapOI[qlvi] = this;

  OutlineItem::isOutlineV = OutlineItem::isTodoV = OutlineItem::isProgressV = false;
  OutlineItem::isNumericV = true;

  numerator=0;
  denominator=10;
  OutlineItem::denInc=1.0;
  OutlineItem::value=1.0;

  pmr = new pmResource();
  QPixmap *pm_ref = pmr->getPmB(0);
  qlvi->setPixmap(0,*pm_ref);
  delete pm_ref;

}

// destructor
NumericItem::~NumericItem() {
  rDebug("pi destructor called %s",this->text().latin1());
  delete pmr;
}

// specific NumericItem support routines
int NumericItem::getNumerator() {
  return numerator;
}

int NumericItem::getDenominator() {
  return denominator;
}

void NumericItem::setNumerator(int n) {
  numerator = n;
}

void NumericItem::setDenominator(int d) {
  denominator = d;
}

// re-implemented from OutlineItem to save item of this class

void NumericItem::itemOutput(QTextStream& out) {
  out << this;
}

// shared with progress items

void NumericItem::updateBar() {

  OutlineItem::value = float(numerator) / float(denominator);

  QPixmap *pm_ref = pmr->getPmFracB(OutlineItem::value);
  qlvi->setPixmap(0,*pm_ref);
  delete pm_ref;

  //rDebug("ub-ni: %s",text().latin1());

  if (parent()) 
    parent()->updateBar();
}


// private

QTextStream& operator<<(QTextStream &out, NumericItem* node) {

  //  return out << (OutlineItem*) node;
  
  for (int i = 0; i <= node->depth(); i++) {
    out << '*';
  }
  //out << node->getNumber();

  out << '[' << node->getNumerator() << '/' << node->getDenominator() << ']';

  if (node->listView()->sEventDates()) {
    if (node->edate) {
      QDate *d = node->edate;
      out << '{' << d->year() << '/' << d->month() << '/' << d->day()  << '}';
    }
  }

  if (node->ddate) {
    QDate *d = node->ddate;
    out << '<' << d->year() << '/' << d->month() << '/' << d->day()  << '>';
  }

  out << ' ' << node->plainText(0) << '\n';

  for (int i=0; i<node->piBlanks; i++) {
    out << '\n';
  }

  if (node->note)
    out << *(node->note);

  for (int i=0; i<node->pnBlanks; i++) {
    out << '\n';
  }

  return out;
}

