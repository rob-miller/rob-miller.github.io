/*
 * OutlineItem.h
 *
 *  class definition for generic outline items.
 *  inherits class Numbered
 *
 *  This file is part of Prozect.
 *  Copyright (C) 2003 Robert T. Miller
 *  
 *  Prozect is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  Prozect is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with Prozect; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  
*************************/

#ifndef OUTLINEITEM_H
#define OUTLINEITEM_H

#include "qlvic.h"

#include <qlistview.h>
#include <qtextstream.h>
#include <qdatetime.h>
#include <stack.h>

class Outline;

class OutlineItem {
 public:
  OutlineItem(Outline *list, QString &text, bool isOutline=TRUE);
  OutlineItem(OutlineItem *parent, QString &text, bool isOutline=TRUE);
  virtual ~OutlineItem();

  virtual OutlineItem *mapToOI(QListViewItem *);
  virtual void itemOutput(QTextStream& out);

  void replicate(OutlineItem *src);

  bool isOutline();
  bool isTodo();
  bool isProgress();
  bool isNumeric();

  // delete/trash/hidden ToDos
  void treeDelete();
  void trash(OutlineItem *);
  void unTrash();
  void emptyTrash();
  int hOICount();
  void setVisible(bool);
  bool isVisible();

  // item number access
  virtual int getNumber() const;
  virtual void setNumber(int);
  virtual bool getNumbering();
  virtual void setNumbering(bool);
  virtual QString getNumberFormatted();

  // item entry/due date access
  bool dateSort();
  bool eDate();
  void showItemAge(bool on);

  // relevant for ToDo items
  virtual void showCompletedTodos(bool state);
  bool kidsCompleted();
  bool haveCompletedActions();
  void purgeActions();

  // relevant for Completion or Progress items
  virtual void updateBar();
  float getValue();
  float getDenInc();

  // re-implemented from QListViewItem and/or QCheckListItem

  virtual int depth() const;
  virtual int childCount() const;
  virtual bool isOpen();
  virtual void setOpen(bool);
  virtual bool isOn();
  virtual void setOn(bool);
  virtual bool isSelected();

  virtual OutlineItem * parent();
  virtual OutlineItem * firstChild();
  virtual OutlineItem * nextSibling();
  virtual OutlineItem * itemAbove();
  virtual OutlineItem * itemBelow();

  virtual void insertItem(OutlineItem *);
  virtual void takeItem(OutlineItem *);
  virtual QListViewItem * getItem();
  virtual Outline * listView();

  void sortChildItems(int, bool);
  virtual void setPixmap( int column, const QPixmap & pm );
  virtual QString text(int col=0) const;
  virtual void setText(int, const QString &);
  virtual QString plainText(int c=0) const;

  // for maintaining format of an emacs outline mode input file
  int piBlanks;   // post-item blank lines
  int pnBlanks;   // post note blank lines

  // public variables
  Qlvic *qlvi;
  QString *note;
  QDate *edate;
  QDate *ddate;

 protected:

  bool isOutlineV;
  bool isTodoV;
  bool isProgressV;
  bool isNumericV;
  bool visible;
  bool eDateVal;
  float denInc;
  float value;


 private:
  // routines
  friend QTextStream& operator<<(QTextStream& out, OutlineItem* node);  

  // variables
  stack<OutlineItem *> hidden;
  stack<OutlineItem *> trashCan;


};

#endif


