#ifndef QT_NO_DEBUG
#define rDebug qDebug
#else
static void rDebug(const char *,...) {}
#endif
