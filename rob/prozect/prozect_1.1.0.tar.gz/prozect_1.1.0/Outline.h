/*******
 *
 * outline.h
 *
 * class Outline
 *
 * Toplevel of OutlineItem/TodoItem hierarchy; placeholder for QListView class.
 *
 *  This file is part of Prozect.
 *  Copyright (C) 2003 Robert T. Miller
 *  
 *  Prozect is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  Prozect is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with Prozect; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  
******/
#ifndef OUTLINE_H
#define OUTLINE_H

#include <qlistview.h>
#include <map.h>
#include <stack.h>

class OutlineItem;
class Prozect;

typedef map<QListViewItem *,OutlineItem *>OImap;

class Outline : public QListView {
  //Q_OBJECT
 public:
  // routines
  Outline(Prozect *main, QWidget *parent=0, const char *name=0);
  ~Outline();

  Prozect * getProz();
  void fullSort();

  void trash(OutlineItem *);
  void unTrash();
  void emptyTrash();

  void showItemAge(bool on);
  bool dateSort();
  bool dateSort(bool);
  bool sEventDates();

  void showCompletedTodos(bool state);
  void purgeActions();
  bool haveCompletedActions();

  // re-implemented from QListViewItem
  OutlineItem * firstChild();
  OutlineItem * currentItem();
  OutlineItem * selectedItem();
  void ensureItemVisible(OutlineItem *);
  void setSelected(OutlineItem *, bool);
  void setCurrentItem(OutlineItem *);
  void setOpen(OutlineItem *, bool);
  void clear();
  void insertItem(OutlineItem *);
  void takeItem(OutlineItem *);

  // public data
  OImap mapOI;
  enum columns { textCol, dateCol, noteCol };
  
 private:
  stack<OutlineItem *> hidden;
  stack<OutlineItem *> trashCan;
  Prozect *topLevel;
  bool dateSortVal;
};

#endif

