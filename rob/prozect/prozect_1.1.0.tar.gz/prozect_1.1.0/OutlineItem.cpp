/**********************
 *
 * OutlineItem.cpp
 *
 * function implementation for OutlineItem class
 *
 *  This file is part of Prozect.
 *  Copyright (C) 2003 Robert T. Miller
 *  
 *  Prozect is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  Prozect is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with Prozect; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  
 *********************/

#include "Outline.h"
#include "OutlineItem.h"
#include "TodoItem.h"

#include "debug.h"

// constructor, called with Outline (QListView) as parent

OutlineItem::OutlineItem(Outline *list, QString &text, bool isOutline=TRUE) 
  : isOutlineV(isOutline) {

  //rDebug("OutlineItem constructor-o: entry %s isOutline=%d",text.latin1(),isOutline);

  if (isOutline) {
    qlvi = new Qlvic(list,text,this);  //QListViewItem(list,text);
    list->mapOI[qlvi] = this;
    isTodoV = isProgressV = isNumericV = false;
  }
  
  note = NULL;
  //edate = new QDate(QDate::currentDate());
  edate = NULL;
  ddate = NULL;
  visible=true;
  eDateVal=false;

  value = 0.0;
  denInc = 0.0;

  piBlanks = pnBlanks = 0;
}

// constructor, called with OutlineItem (QListViewItem) as parent

OutlineItem::OutlineItem(OutlineItem *parent, QString &text, bool isOutline=TRUE) 
  : isOutlineV(isOutline) {
  //rDebug("OutlineItem constructor-oi: entry %s isOutline=%d",text.latin1(),isOutline);

  if (isOutline) {
    qlvi = new Qlvic(parent->qlvi,text,this); 
    Outline *list = (Outline *) qlvi->listView();
    list->mapOI[qlvi] = this;
    isTodoV = isProgressV = isNumericV = false;
  }
    
  note=NULL;
  //edate = new QDate(QDate::currentDate());
  edate = NULL;
  ddate = NULL;
  visible=true;
  eDateVal=false;

  value = 0.0;
  denInc = 0.0;

  piBlanks = pnBlanks = 0;
}

// destructor
OutlineItem::~OutlineItem() {

  rDebug("oi destructor called %s",text(0).latin1());

  OutlineItem *coi = firstChild();
  while (coi) {
    rDebug("~oi destroying child %s",coi->text(0).latin1());
    OutlineItem *noi = coi->nextSibling();
    delete coi;
    coi = noi;
  }

  if (qlvi) {
    //rDebug("oi destructor called: %s",this->text().latin1());
    listView()->mapOI[qlvi] =NULL;  //how to delete the map entry ?
    delete qlvi;
  }
  qlvi=NULL;

  delete note;
  note=NULL;
  delete edate;
  edate=NULL;
  delete ddate;
  ddate=NULL;

  rDebug("oi destructor finished");
}

// return the OutlineItem for which the passed QListViewItem is a member
OutlineItem * OutlineItem::mapToOI(QListViewItem *qlvi) {
  //rDebug("enter mapToOI");
  if (qlvi == NULL) {
    //rDebug("mapToOI-outline: qlvi is NULL!");
    return NULL;
  }
  return listView()->mapOI[qlvi];
}

// print routine
void OutlineItem::itemOutput(QTextStream& out) {
    out << this;
}

// copy non-pointer variables from source OutlineItem to self
void OutlineItem::replicate(OutlineItem *src) {
  ddate = src->ddate;
  edate = src->edate;
  note = src->note;
  setText(Outline::dateCol,src->text(Outline::dateCol));
  visible = src->visible;
  eDateVal = src->eDateVal;
  value = src->value;
  denInc = src->denInc;
  setOpen(src->isOpen());
}

// informational, re-implemented as needed for each item class
bool OutlineItem::isOutline() {
  return isOutlineV;
}

bool OutlineItem::isTodo() {
  return isTodoV;
}

bool OutlineItem::isProgress() {
  return isProgressV;
}

bool OutlineItem::isNumeric() {
  return isNumericV;
}

// delete/trash items, hidden todos

void OutlineItem::treeDelete() {
  OutlineItem * myChild = firstChild();
  if (myChild) myChild->treeDelete();
  OutlineItem * mySibling = nextSibling();
  if (mySibling) mySibling->treeDelete();
  delete this;
}

void OutlineItem::trash(OutlineItem *oi) {
  rDebug("oi trash %s",oi->text().latin1());
  trashCan.push(oi);
  takeItem(oi);
}

void OutlineItem::unTrash() {
  if (trashCan.size()>0) {
    rDebug("oi unTrashing item %s",trashCan.top()->text().latin1());
    insertItem(trashCan.top());
    trashCan.pop();
  }
}

void OutlineItem::emptyTrash() {
  OutlineItem *oi;

  while (trashCan.size()>0) {
    oi = trashCan.top();
    rDebug("oi purging item %s",oi->text().latin1());
    insertItem(oi);
    delete (oi);
    //rDebug("item deleted");
    trashCan.pop();
  }

  oi = firstChild();

  while (oi) {
    oi->emptyTrash();
    oi = oi->nextSibling();
  }
}

// return count of hidden OutlineItems
int OutlineItem::hOICount() {
  return hidden.size();
}

void OutlineItem::setVisible(bool viz) {
  visible = viz;
  //rDebug("setVisible %s =%d",text().latin1(),viz);
}

bool OutlineItem::isVisible() {
  return visible;
}

// access functions for class numbered

int OutlineItem::getNumber() const {
  return qlvi->getNumber();
}

void OutlineItem::setNumber(int n) {
  qlvi->setNumber(n);
}

bool OutlineItem::getNumbering() {
  return qlvi->getNumbering();
}

void OutlineItem::setNumbering(bool b) {
  //rDebug("oi setNumbering(%d) %s",b,text().latin1());
  qlvi->setNumbering(b);
  qlvi->widthChanged();
  qlvi->repaint();
  OutlineItem *oi = firstChild();
  while(oi) {
    oi->setNumbering(b);
    oi = oi->nextSibling();
  }
}

QString OutlineItem::getNumberFormatted() {
  return qlvi->getNumberFormatted();
}

// entry/due date access

bool OutlineItem::dateSort() {
  return listView()->dateSort();
}

bool OutlineItem::eDate() {
  return eDateVal;
}

// display days to entry date or due date according to parameter
void OutlineItem::showItemAge(bool on) {
  int dt=0;
  eDateVal=on;

  if (on) {
    dt = - QDate::currentDate().daysTo(*edate);
    setText(Outline::dateCol, QString::number(dt));
  } else if (ddate) {
    dt = QDate::currentDate().daysTo(*ddate);
    setText(Outline::dateCol, QString::number(dt));
  } else {
    setText(Outline::dateCol,QString::null);
  }
  OutlineItem *oi = firstChild();
  while (oi) {
    oi->showItemAge(on);
    oi = oi->nextSibling();
  }
}

// member functions primarily relevant for ToDo item subclass

void OutlineItem::showCompletedTodos(bool state) {

  OutlineItem *oi;

  if (state) {  // show any hidden ones
    //if (hidden.size()) 
    //  rDebug("unhiding %d items",hidden.size());

    while (hidden.size()>0) {
      rDebug("oi unhiding item %s",hidden.top()->text().latin1());
      insertItem(hidden.top());
      hidden.pop();
    }

    oi  = firstChild();
    if (oi)
      oi->showCompletedTodos(state);

  } else { // hide any completed ones
    //rDebug("sct-oi: hide");

    oi  = firstChild();
    while(oi) {

      if (oi->isOn()) { // only completed Todos have this
	rDebug("hide %s",oi->text().latin1());
	hidden.push(oi);
	OutlineItem *noi = oi->nextSibling();
	takeItem(oi);
	oi = noi;
      } else { // not completed or not a Todo, check children
	oi->showCompletedTodos(state);
	oi = oi->nextSibling();
      }

    }
  }


  // not top-level list, process my sibling.

  //rDebug("sct-oi %s: processing sibling ",text().latin1());
  oi = nextSibling();
  if (oi)
    oi->showCompletedTodos(state);
  //rDebug("sct-oi %s: my sibling finished",text().latin1());
}

bool OutlineItem::kidsCompleted() {
  rDebug("%s kidsComp",text().latin1());
  if (! isVisible()) return(isOn());
  OutlineItem *oi = firstChild();
  rDebug("kid = %d",(int)oi);
  while (oi) {
    rDebug("%s kidsComp: child %s",text().latin1(),oi->text().latin1());
    if (oi->isOn())
      oi = oi->nextSibling();
    else
      return false;
  }
  return true;
}


bool OutlineItem::haveCompletedActions() {

  OutlineItem *oi = firstChild();
  while (oi) {
    if (oi->isOn())
      return true;
    else if (oi->hOICount() >0)
      return true;
    else if (oi->haveCompletedActions())
      return true;
    else
      oi = oi->nextSibling();
  }
  return false;
}

void OutlineItem::purgeActions() {

  if (isOn()) {
    delete this;
    return;
  }

  OutlineItem *oi = firstChild();
  OutlineItem *noi;
  while (oi) {
    noi = oi->nextSibling();
    if (oi->isOn())
      delete oi;
    else 
      oi->purgeActions();
    oi = noi;
  }
}


// place holders relevant only for Progress and Numeric item subclasses

void OutlineItem::updateBar() {
  //rDebug("ub-oi: %s",text().latin1());
}

float OutlineItem::getValue() {
  return value;
}

float OutlineItem::getDenInc() {
  return denInc;
}


// re-implemented from QListViewItem
// TodoItem class re-implements from QCheckListItem

int OutlineItem::depth() const {
  return qlvi->depth();
}

int OutlineItem::childCount() const {
  return qlvi->childCount();
}

bool OutlineItem::isOpen() {
  return qlvi->isOpen();
}

void OutlineItem::setOpen(bool o) {
  qlvi->setOpen(o);
}


bool OutlineItem::isOn() {
  return false;
}

void OutlineItem::setOn(bool)
{
} // setOn()

bool OutlineItem::isSelected() {
  return qlvi->isSelected();
}

OutlineItem * OutlineItem::parent() {
  return (qlvi ? mapToOI(qlvi->parent()) : NULL);
}

OutlineItem * OutlineItem::firstChild() {
  return (qlvi ? mapToOI(qlvi->firstChild()) : NULL);
}

OutlineItem * OutlineItem::nextSibling() {
  return (qlvi ? mapToOI(qlvi->nextSibling()) : NULL);
}

OutlineItem * OutlineItem::itemAbove() {
  return mapToOI(qlvi->itemAbove());
}

OutlineItem * OutlineItem::itemBelow() {
  return mapToOI(qlvi->itemBelow());
}

void OutlineItem::insertItem(OutlineItem *oi) {
  qlvi->insertItem(oi->getItem());
  oi->setVisible(true);
}

void OutlineItem::takeItem(OutlineItem *oi) {
  oi->setVisible(false);
  qlvi->takeItem(oi->getItem());
}

QListViewItem * OutlineItem::getItem() {
  return qlvi;
}

Outline * OutlineItem::listView() {
  return (Outline *) qlvi->listView();
}

void OutlineItem::sortChildItems(int i, bool b) {
  qlvi->sortChildItems(i,b);
}

void OutlineItem::setPixmap( int column, const QPixmap & pm ) {
  qlvi->setPixmap( column, pm );
}

QString OutlineItem::text(int col=0) const {
  return (qlvi ? qlvi->text(col) : QString::null);
}

void OutlineItem::setText(int col, const QString &newText) {
  qlvi->setText(col,newText);
}

QString OutlineItem::plainText(int column=0) const {
  return qlvi->plainText(column);
}


// private routines

QTextStream& operator<<(QTextStream &out, OutlineItem* node) {
  for (int i = 0; i <= node->depth(); i++) {
    out << '*';
  }
  //  out << node->getNumber();

  if (node->listView()->sEventDates()) {
    if (node->edate) {
      QDate *d = node->edate;
      out << '{' << d->year() << '/' << d->month() << '/' << d->day()  << '}';
    }
  }

  if (node->ddate) {
    QDate *d = node->ddate;
    out << '<' << d->year() << '/' << d->month() << '/' << d->day()  << '>';
  }

  out << ' ' << node->plainText(0) << '\n';

  for (int i=0; i<node->piBlanks; i++) {   
    out << '\n';
  }

  if (node->note)
    out << *(node->note); 

  for (int i=0; i<node->pnBlanks; i++) {
    out << '\n';
  }

  //out << endl;
  return out;
}






