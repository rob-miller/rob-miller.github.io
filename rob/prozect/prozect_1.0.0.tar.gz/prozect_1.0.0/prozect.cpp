/*
 *  prozect.cpp
 *
 *  This file is part of Prozect.
 *  Copyright (C) 2003 Robert T. Miller
 *  
 *  Prozect is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  Prozect is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with Prozect; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  
 */

#include "moc_prozect.cpp"

#include "OutlineItem.h"
#include "TodoItem.h"
#include "Outline.h"
#include "ProgressItem.h"
#include "NumericItem.h"
#include "prozIO.h"

#include <qapplication.h>
#include <qmessagebox.h>
#include <qlayout.h>
#include <qaccel.h>
#include <qlineedit.h>
#include <iostream.h>
#include <qtextcodec.h>

#include <qpixmap.h>
#include <qpe/resource.h>

#include <qpopupmenu.h>
#include <qinputdialog.h>
#include <qstylesheet.h>
#include <qwhatsthis.h>
#include <qtooltip.h>
#include <qpe/config.h>
#include <qpe/timestring.h>
#include <qdatetime.h>

#include "debug.h"

#define MIMETYPE "application/prozect"

// define TIMING to enable time profiling
//#define TIMING 1

#ifdef TIMING
#include <qdatetime.h>
QTime t;
#define TIMCHK(fn) printf("time: " fn " %d\n",t.restart())
#else
#define TIMCHK(fn)
#endif

static int u_id=1;   // unique id for widgets


//*********** public member routines

// class constructor:
Prozect::Prozect(QWidget* parent, const char* name, WFlags fl)
  : QMainWindow(parent, name, fl) {

#ifdef TIMING
  t.start();
  printf("Prozect timing started %s\n",t.toString().latin1());
#endif

  prozStack = new QWidgetStack(this);
  setCentralWidget(prozStack);

  //QStyleSheet(this);
  lastDCheck=NULL;

  TIMCHK("Qt widget stuff");

  initialiseNoteEdit();
  TIMCHK("initNoteEdit");
  initialiseFileSelect();
  TIMCHK("initFileSel");
  initialiseMenu();
  TIMCHK("initMenu");
  initialiseToolBar();
  TIMCHK("initToolBar");
  initialiseShortcuts();
  TIMCHK("initShortCuts");
  initialiseTextWidgets();
  TIMCHK("initTextWidgs");

  list = new Outline(this, prozStack, "List");
  QWhatsThis::add(list->header(),"Adjust column widths here");

  TIMCHK("new list");

  prozStack->addWidget(list, u_id++);
  prozStack->addWidget(qmle, u_id++);

  TIMCHK("add widgets");

  list->addColumn("item",160);
  list->addColumn("days");
  list->addColumn("note");

  TIMCHK("add cols");

  is_clean=true;
  onCount=0;

  showFileSelect();

  TIMCHK("show filesel");

  selected = NULL;
  lastSelected = NULL;

  connect(list, SIGNAL(selectionChanged()),
	  this, SLOT(sSelectionChanged()));  

  connect(list, SIGNAL(clicked(QListViewItem *,const QPoint &,int)),
	  this, SLOT(sItemClicked(QListViewItem *,const QPoint &,int)));

  TIMCHK("connections");

  updateCaption();

  TIMCHK("prozect constructor finished");

  rcLoad();

  TIMCHK("rcload finished");
}

//class destructor:
Prozect::~Prozect(){
  TIMCHK("prozect destructor starting");
  rDebug("~1");
  sNewOutline();
  rDebug("~2");
  delete file;
  rDebug("~3");
  delete help;
  rDebug("~4");
  delete options;
  rDebug("~5");
  delete menu;
  rDebug("~6");
  delete lineEdit;
  rDebug("~7");
  delete btnLeft;
  rDebug("~8");
  delete btnUp;
  rDebug("~9");
  delete btnDown;
  rDebug("~10");
  delete btnRight;
  rDebug("~11");
  delete itemTypes;
  rDebug("~12");
  delete cBoxItemTypes;
  rDebug("~13");
  delete btnNew;
  rDebug("~14");
  delete btnDel;
  rDebug("~15");
  delete btnDate; 
  rDebug("~16");
  delete btnDelDate;
  rDebug("~17");
  delete toolBar2;
  rDebug("~18");
  delete qmle;
  rDebug("~19");
  delete getNiNumDenW;
  rDebug("~20");
  delete getNameW;
  rDebug("~21");
  delete getNoteW;
  rDebug("~22");  
  delete toolBar;
  rDebug("~23");
  delete list;
  rDebug("~24");
  delete prozStack; 
  rDebug("~25");
  delete lastDCheck;
  rDebug("~26");
  TIMCHK("prozect destructor finished");
}

// supporting public routines

// turn off the selection of an item in the QListView
void Prozect::clearSelection() {
  list->clearSelection();
  selected=NULL;
}

// keep track of the number of completed ToDo items; if 
//  1 or more completed items, the 'purge completed items' menu
//  entry should be enabled.
void Prozect::countOn(bool on) {
  onCount += (on ? 1 : -1);
  if (onCount == 1) 
    options->setItemEnabled(purge_id,true);
  else if (onCount <= 0)
   options->setItemEnabled(purge_id,false);

  rDebug("countOn %d on",onCount);
}

// helper function to report state of 'show Completed Actions' preference
bool Prozect::sct() {
  return options->isItemChecked(sCompleted_id);
}

// helper function to report state of 'child completes parent' preference
bool Prozect::ccp() {
  return options->isItemChecked(cCP_id);
}

// helper function to report state of 'parent completes child' preference
bool Prozect::pcc() {
  return options->isItemChecked(pCC_id);
}


//************** public member slots

// slot routines supporting Outline menu

void Prozect::sOpen() {

  if (! sNewOutline()) 
    return;

  showFileSelect();

}

void Prozect::sSave()
{
  if (currDoc.name().isEmpty()) {
    if (! setFileName()) 
      return;
  }

#ifdef DEMO
  QMessageBox::about(this,"Prozect demo","sorry, file save is disabled in this demo");
#else
  if (!sct())
    list->showCompletedTodos(true);

  renumberBranch();

  while (!saveTree()) {
    QMessageBox::warning(this, "file problem", "error writing file "+currDoc.file()+" !", "try again");
    if (! setFileName()) {
      if (!sct())
	list->showCompletedTodos(false);
      return;
    }
  }
  updateCaption();

  if (!sct())
    list->showCompletedTodos(false);
#endif

}

void Prozect::sUnDeleteNode() {

  //if (selected) 
  //  list->setSelected(selected,false);

  if (trashStack.size() >0) {
    OutlineItem *oi = trashStack.top();
    if (oi) {
      oi->unTrash();
      renumberBranch(oi);
    } else {
      list->unTrash();
      renumberBranch();
    }
    trashStack.pop();

    if (trashStack.size() <= 0) {
      file->setItemEnabled(undel_id,false);
      options->setItemEnabled(emptyT_id,false);
    }

  } 

  //list->triggerUpdate();
}

// Exit
void Prozect::sQuit() {
  if (!checkForSave()) return;
  this->close();
}

// slot routines supporting Options menu

// show numbers for each outline item
void Prozect::sToggleNumbering() {

  setNumbering(toggleItem(numbering_id));

  //rDebug("toggleNumbering, curr state= %d\n",options->isItemChecked(numbering_id));

}

// show the item creation date or the item due date in the Date button when the item is selected
void Prozect::sToggleItemDate() {
  toggleItem(itemDate_id);
  setBtnDate();
}

// show the days since item creation or the days to due date in the 'days' column
void Prozect::sToggleAge() {
  list->showItemAge(toggleItem(age_id));
}

// sort each outline subsection by the current value in the 'days' column
void Prozect::sToggleSortDate() {
  list->dateSort(toggleItem(sortDate_id));
  list->fullSort();
  list->triggerUpdate();
}

// save current file without asking on exit or opening another file
void Prozect::sAutosave() {
#ifdef DEMO
  QMessageBox::about(this,"Prozect demo","sorry, file save is disabled in this demo");
#else
  toggleItem(autosave_id);
#endif
}

// Todo item specific options:

// hide ToDo items which have been checked off
void Prozect::sToggleShowCompleted() {

  clearSelection();
  list->showCompletedTodos(toggleItem(sCompleted_id));

  setNumbering(options->isItemChecked(numbering_id));

  //rDebug("sToggleShowCompleted, curr state= %d\n",options->isItemChecked(sCompleted_id));
}

// parent completes child -- checking the parent item will automatically check all the children that are ToDo items
void Prozect::sTogglePCC() {
  toggleItem(pCC_id);
}

// child completes parent -- for a ToDo item with ToDo item children, checking all the children will automatically check the parent
void Prozect::sToggleCCP() {
  toggleItem(cCP_id);
}

// *actions* that aren't really options, but they are optional and I couldn't think of another name for the menu!

// delete all completed ToDo items, whether shown or not
void Prozect::sPurgeActions() {
  if (selected && selected->isOn()) {
    selected->purgeActions();
    selected=NULL;

    if (! list->haveCompletedActions()) 
      options->setItemEnabled(purge_id,false);

  } else if (selected) {
    if (! sct()) 
      selected->showCompletedTodos(true);

    selected->purgeActions();

    if (! sct()) 
      selected->showCompletedTodos(true);

    selected->updateBar();

    if (! list->haveCompletedActions()) 
      options->setItemEnabled(purge_id,false);

  } else {
    if (! sct()) 
      list->showCompletedTodos(true);

    list->purgeActions();

    if (! sct()) 
      list->showCompletedTodos(false);

    options->setItemEnabled(purge_id,false);
  }

  renumberBranch();
}

// really delete all items which have been deleted (used the trashcan item), i.e. empty the trash
// yes, you can show completed items, check a todo item, put it in the trash, purge completed items, 
// undelete, and get the checked todo item back.
void Prozect::sPurgeTrash() {
  while (trashStack.size() >0) 
    trashStack.pop();
  list->emptyTrash();

  file->setItemEnabled(undel_id,false);
  options->setItemEnabled(emptyT_id,false);

  renumberBranch();
}


// slot routines supporting Help menu
void Prozect::sAboutProzect() {
   QString aboutText;
   aboutText.sprintf("Prozect:\n"
		     " a hierarchical outliner/todo list.\n"
#ifdef DEMO
		     " file save is disabled in this demo\n"
#else
		     "   \"A Progect clone for the Zaurus\"\n"
#endif
		     "Version: %s\n"
		     "Build date:\n %s\n\n"
		     "Author: Rob Miller\n"
		     "Email: rob at janerob dot com\n"
		     "Licence : GNU Public Licence", VERSION, BUILDTIME);
   QMessageBox::about(this, "Prozect", aboutText.latin1());
}

// general help dialog		    
void Prozect::sGenHelp() {
   QString gHelpText;
   gHelpText.sprintf("Help Options:\n"
		     "(1) Read the tutorial\n"
		     "(2) Select the \"What's This mode\" \n"
		     "     and tap on a button or menu item\n"
		     "(3) Just try a few things and\n"
		     "     see how it works!\n"
		     "     -- Problems? check (1) or (2)\n");
   QMessageBox::about(this, "Prozect Help", gHelpText.latin1());
}

void Prozect::sAboutQt() {
   QMessageBox::aboutQt(this, "Prozect");
}




// slot routines supporting menu bar buttons (currently only item date controls)

// date button clicked, set as item due date.
void Prozect::sAddDate( int y, int m, int d) {

  //printf("date Selected");

  if (! selected && ! lineEdit->text().isEmpty()) { // adding a new item
    insertNode(true);
    lineEdit->end(false); 

    rDebug("set date while adding new item");
  }

  if (!selected) {  // spurious button press
    setBtnDate();
    //defState();
    return;
  }

  // if here, have either a newly inserted item or an existing selected item

  //QDate date(y,m,d);
  //int dt = QDate::currentDate().daysTo(date);

  if (selected->ddate) 
    selected->ddate->setYMD(y,m,d);
  else
    selected->ddate = new QDate(y,m,d);

  //selected->setText(Outline::dateCol, QString::number(dt));
  selected->showItemAge(options->isItemChecked(age_id));
  setBtnDate();

  is_clean=false;
  
  //defState();
  //list->clearSelection();  // assume we want to keep working on it
}

// delete (clear) an item's due date
void Prozect::sDelDate() {
  if (! selected)
    return;

  if (selected->ddate) {
    
    delete selected->ddate;
    selected->ddate =0;
    //selected->setText(Outline::dateCol, QString::null);
    selected->showItemAge(options->isItemChecked(age_id));
    setBtnDate();
    is_clean=false;
  }

}

// slot routines to support toolbar controls

// <enter> pressed in the LineEdit widget; insert as a new node, or update the currently selected node.
void Prozect::sDoLineEdit() {
  if (selected) {  
    selected->setText(Outline::textCol,lineEdit->text());
    if (selected->isNumeric()) 
      ni_getNumDen((NumericItem*)selected);
    list->clearSelection();
    selected=NULL;
    lineEdit->clear();
    lineEdit->setFocus();
    setBtnDate();
    //defState();
  } else {
    insertNode();
  }

  is_clean = false;
}

// left, down, up, right button presses; move the currently selected item
void Prozect::sMoveNodeLeft() {
  if (showQMLE) return;
  if (!selected) return;

   OutlineItem *new_parent=0;
   if (selected->depth() == 0) 
     return; // it can't go any farther left

   OutlineItem *top = list->firstChild();
   bool currNstate = top->getNumbering();
   if (currNstate) 
     top->setNumbering(false);

   OutlineItem *par = selected->parent();
   int newNum = par->getNumber()+1;

   rDebug("moveNodeLeft: was %d parent is %d will be %d",selected->getNumber(),par->getNumber(),newNum);

   //rDebug("moveUp?  num= %d  newNum=%d %d",selected->getNumber(),newNum);

   forceNumSort(true);

   if (selected->depth() == 1) {
     selected = moveSubTree(list, selected);
     makeHole(par->nextSibling(),newNum+1);
     rDebug("moveNodeLeft-list: was %d parent (%s) is %d will be %d",selected->getNumber(),par->text().latin1(),par->getNumber(),newNum);
     selected->setNumber(newNum);
     list->sort();
   } else {
      new_parent = par->parent();
      selected = moveSubTree(new_parent, selected);
      makeHole(par->nextSibling(),newNum+1);
      //rDebug("moveNodeLeft-oi: was %d parent (%s) is %d will be %d",selected->getNumber(),par->text().latin1(),par->getNumber(),newNum);
      selected->setNumber(newNum);
      new_parent->sortChildItems(0,false);
      new_parent->sortChildItems(0,true);
      new_parent->updateBar();
      par->updateBar();
   }

    // //while (selected->getNumber() > newNum) {
    //while (par->nextSibling() != selected) {
    // rDebug("curr: %d  targ: %d",selected->getNumber(),newNum);
    // sMoveNodeUp();
    //}

   //rDebug("all done - sel= %s, num= %d newNum=%d ",selected->text().latin1(),selected->getNumber(),newNum);

   renumberBranch(par);  // could be a preference, this is the progect behaviour
   renumberBranch(new_parent);  // if np=0, renumbers list

   if (currNstate) 
     top->setNumbering(currNstate);

   forceNumSort(false);
   
   list->setSelected(selected, true);
   list->ensureItemVisible(selected);
   is_clean = false;

   //defState();
}

void Prozect::sMoveNodeUp() {

  if (showQMLE) return;
  if (!selected) return;

  //rDebug("selected is %s",selected->text(0).latin1());

  forceNumSort(true);

  OutlineItem *par = selected->parent();
  if (par) {
    par->sortChildItems(0, false);
    par->sortChildItems(0, true);
    //rDebug("1st sorts done");
  }

   OutlineItem *node = selected;

   OutlineItem *sibling;
   if (node->depth() == 0) {
     sibling = list->firstChild();
     rDebug("depth is 0, node= %d",(int)sibling);
   } else {
     sibling = node->parent()->firstChild();
     rDebug("depth is %d, node= %d",node->depth(),(int)sibling);
   }
   while (sibling && (sibling->nextSibling() != node)) {
     //rDebug("skip posn %d %s",sibling->getNumber(),sibling->text(0));
     sibling = sibling->nextSibling();
   }
   if (sibling) {
     rDebug("found sibling with number %d",sibling->getNumber());
     int newNum = sibling->getNumber();
     node->setNumber(newNum);
     sibling->setNumber(newNum+1);  // guarantee swap order of these two
   } else {
     rDebug("found no sibling with me as successor");
   }

   if (par) {
     par->sortChildItems(0, false);
     par->sortChildItems(0, true);
   } else {
     list->sort();
   }
   forceNumSort(false);

   rDebug("finished 2nd sort");
   list->triggerUpdate();
   is_clean = false;
   //rDebug("update triggered, done.");

   //defState();
}

void Prozect::sMoveNodeDown()
{
  if (showQMLE) return;
  if (!selected) return;
  if (!selected->nextSibling()) return;
  
  OutlineItem *par = selected->parent();
  forceNumSort(true);

  if (par) {
    par->sortChildItems(0, false);
    par->sortChildItems(0, true);
  } 

  OutlineItem *next = selected->nextSibling();
  OutlineItem *node = selected;
  int newNum = next->getNumber();
  node->setNumber(newNum);
  next->setNumber(newNum-1);  // guarantee swap order of these two

  if (par) {
    par->sortChildItems(0, false);
    par->sortChildItems(0, true);
  } else {
    list->sort();
  }
  forceNumSort(false);

  list->triggerUpdate();
  is_clean = false;

  //defState();
}

void Prozect::sMoveNodeRight() {

  if (showQMLE) return;
  if (!selected) return;

  OutlineItem *above = selected->itemAbove();
  if (above == NULL) return;
  while (above->depth() > selected->depth()) {
    above = above->parent();
  }
  
  OutlineItem *top = list->firstChild();
  bool currNstate = top->getNumbering();
  top->setNumbering(false);

  forceNumSort(true);

  selected = moveSubTree(above, selected);

  //if (above->parent()) renumberBranch(above->parent());
  //else 

  if (above->parent()) 
    above->parent()->sortChildItems(0,true);
  else
    list->sort();

  renumberBranch();

  forceNumSort(false);

  top->setNumbering(currNstate);

  list->setSelected(selected, true);
  list->ensureItemVisible(selected);
  list->setOpen(above, true);
  is_clean = false;

  //defState();
}

// item type listbox activated, implement change as needed for currently selected item
void Prozect::sNewItemType(const QString &itype) {
  //rDebug("new type is %s !",itype.latin1());

  if (showQMLE) return;
  if (! selected) return;

  QString text_ref = selected->plainText();
  OutlineItem *par = selected->parent();
  OutlineItem *newItem=NULL;

  if ((selected->isOutline() && (itype == "info"))
      ||
      (selected->isTodo() && (itype == "action"))
      ||
      (selected->isProgress() && (itype == "progress"))
      || 
      (selected->isNumeric() && (itype == "numeric")))
    return;

  newItem = getNode(itype,par,text_ref);

  int newNum = selected->getNumber();
  replaceNode(newItem,selected);
  newItem->setNumber(newNum);

  forceNumSort(true);

  if (par) {
    par->updateBar();
    par->sortChildItems(0,true);
  } else {
    list->sort();
  }

  forceNumSort(false);

  list->setSelected(newItem,true);
  //list->setCurrentItem(newItem);
  selected = lastSelected = newItem;

}

// prepare to create a new item after the currently selected item
void Prozect::sNewBtn() {

  if (showQMLE)
    return;

  if (selected) 
    list->clearSelection();
  else 
    insertNode();
}

// delete (put in trash) the currently selected item
void Prozect::sDeleteNode() {

  rDebug("sDeleteNode entry");

  if (showQMLE)
    return;

  if (!selected) 
    return;

  rDebug("0 sel= %s",selected->text().latin1());

  OutlineItem *tSelected = selected;
  list->setSelected(selected,false);
  selected = lastSelected = tSelected->itemBelow();

  if (selected) 
    rDebug("1 sel= %s",selected->text().latin1());
  else 
    rDebug("1 sel= 0");

  while (selected && selected->depth() > tSelected->depth()) {
    rDebug("sel= %s",selected->text().latin1());
    lastSelected = selected->itemBelow();
    selected = lastSelected;
  }

  if (selected)
    list->setSelected(selected,true);

  if (tSelected->depth() == 0) {
    trashStack.push(0);
    list->trash(tSelected);
    renumberBranch();
  } else {
    OutlineItem *par = tSelected->parent();
    trashStack.push(par);
    par->trash(tSelected);
    renumberBranch(par);
  }

  file->setItemEnabled(undel_id,true);
  options->setItemEnabled(emptyT_id,true);

  is_clean = false;
}

// slot routines to support taps in QListView widget (per column response)

// different item selected, update LineEdit, item type listbox and DateButton widgets
void Prozect::sSelectionChanged() {
  //rDebug("sSelectionChanged");
  selected = list->selectedItem();

  setBtnDate();

  if (selected) {
    //rDebug("schange- selection: %s",selected->text(0).latin1());
    lastSelected = selected;
    lineEdit->setText(selected->plainText(Outline::textCol));
    //lineEdit->setFocus(); // rather have arrow response throughout list.
    lineEdit->home(false);

    // depends on itemTypes text order!!
    if (selected->isOutline()) 
      cBoxItemTypes->setCurrentItem(0);
    else if (selected->isTodo()) 
      cBoxItemTypes->setCurrentItem(1);
    else if (selected->isNumeric()) 
      cBoxItemTypes->setCurrentItem(2);
    else if (selected->isProgress()) 
      cBoxItemTypes->setCurrentItem(3);

  } else {
    //defState();
    lineEdit->clear();
    lineEdit->setFocus();
  }
  //rDebug("sSelectionChanged finished");
}

// item clicked, possibly add/edit associated note or mark ToDo item completed
void Prozect::sItemClicked(QListViewItem *,const QPoint &,int col) {

  //rDebug("item Clicked col %d",col);

  // should confirm selected has been set to *sel, docs say slots are 
  // called in arbitrary (not random) order, and sSelectionChanged()
  // has been called before this slot on platforms tested thus far

  if (! selected) 
    return;

  if (col == Outline::noteCol) 
    addNote();
    
  if (selected->isTodo()
      &&
      ((TodoItem*) selected)->updateCheckBox())
    is_clean = false;


}


// slot routines to support FileSelect GUI actions.

// used more widely than just FileSelect, get the main Prozect GUI up and in default state
void Prozect::sShowProzect() {
  toolBar->show();
  toolBar2->show();
  prozStack->raiseWidget(list);
  menu->show();
  list->clearSelection();
  lineEdit->clear();
  lineEdit->setFocus();
  selected=NULL;
  //defState();
}

// user selected 'new' option; save as necessary, clear everything.
// version without DocLnk called more widely to clear current settings
bool Prozect::sNewOutline() {

  if (!checkForSave()) return false;

  lastSelected=NULL;
  selected=NULL;
  is_clean = true;
  sPurgeTrash();
  list->clear();
  currDoc.setName(QString::null);

  updateCaption();
  sShowProzect();

  return true;
}


bool Prozect::sNewOutline( const DocLnk &f ) {

  if (!checkForSave()) return false;  // should not happen

  lastSelected=NULL;
  selected=NULL;
  is_clean = true;
  sPurgeTrash();
  list->clear();

  setCurrDoc(f);

  if ((! currDoc.name().isEmpty()) && (currDoc.name().findRev(".proz") == -1)) {
    //    QString newName = currDoc.name()+".proz";
    currDoc.setName(currDoc.name()+".proz");
  }

  updateCaption();
  sShowProzect();

  return true;
}

// specify the current outline to be loaded, DocLnk and QStrign versions
// setDocument() is not sSetDocument() to support Qtopia external call
void Prozect::setDocument( const QString& applnk_filename ) {

  currDoc.setName(applnk_filename.right(applnk_filename.length() - (applnk_filename.findRev('/')+1)));
  //rDebug("setDoc-fn: name set to %s",currDoc.name().latin1());
  currDoc.setFile(applnk_filename);
  currDoc.setType(MIMETYPE);

  rDebug("setDoc-filename calling loadfile %s -> %s",applnk_filename.latin1(),currDoc.name().latin1());
  loadFile();

  //rDebug("setDoc back from loadfile");

  list->showCompletedTodos(options->isItemChecked(sCompleted_id));
  list->showItemAge(options->isItemChecked(age_id));

  updateCaption();

  sShowProzect();

  //rDebug("setDoc done");
}

void Prozect::setDocument( const DocLnk &dl ) {

  setCurrDoc(dl);

  rDebug("setDoc-doclnk calling loadfile %s",dl.name().latin1());
  loadFile();

  //rDebug("setDoc back from loadfile");

  list->showCompletedTodos(options->isItemChecked(sCompleted_id));
  list->showItemAge(options->isItemChecked(age_id));

  updateCaption();

  sShowProzect();

  //rDebug("setDoc done");
}


//************** private member routines
// set up GUI elements, add QWhatsThis text

void Prozect::initialiseMenu() {  

   // Create a file menu
   file = new QPopupMenu();

   open_id = file->insertItem("&Open", this, SLOT(sOpen()));
   file->setWhatsThis(open_id,"Open a new or existing Prozect document");

   save_id = file->insertItem("&Save", this, SLOT(sSave()));
   file->setWhatsThis(save_id,"Save the current document, prompt for name if needed");

   undel_id = file->insertItem("Un-delete",this,SLOT(sUnDeleteNode()));
   file->setWhatsThis(undel_id,"Retrieve the last deleted item");
   file->setItemEnabled(undel_id,false);

   file->insertSeparator();

   exit_id = file->insertItem("Exit", this, SLOT(sQuit()));
   file->setWhatsThis(exit_id,"Quit Prozect, prompt to save file if needed");

   // Create an options menu
   options = new QPopupMenu();
   options->setCheckable(true);

   numbering_id = options->insertItem("Show &Numbering", this,SLOT(sToggleNumbering()));
   options->setItemChecked(numbering_id, false); //another preference
   options->setWhatsThis(numbering_id,"Show all item numbers in outline; bug workaround - adjust column width to refresh properly");

   itemDate_id = options->insertItem("Show creation date",this,SLOT(sToggleItemDate()));
   options->setItemChecked(itemDate_id, false); //another preference
   options->setWhatsThis(itemDate_id,"Date button will show date the selected item was first created, not its due date");
   
   age_id = options->insertItem("Show age",this,SLOT(sToggleAge()));
   options->setItemChecked(age_id, false); //another preference
   options->setWhatsThis(age_id,"Date column will show days since item created, not days to due date");
   
   sortDate_id = options->insertItem("Sort on date",this,SLOT(sToggleSortDate()));
   options->setItemChecked(sortDate_id, false); //another preference
   options->setWhatsThis(sortDate_id,"sort items by date shown");
   
   autosave_id = options->insertItem("autoSave", this,SLOT(sAutosave()));
   options->setItemChecked(autosave_id, false); //another preference
   options->setWhatsThis(autosave_id,"Save documents without asking, unless a filename is needed");

   options->insertSeparator();

   sCompleted_id = options->insertItem("Show Completed Actions", this,SLOT(sToggleShowCompleted()));
   options->setItemChecked(sCompleted_id, true); //another preference
   options->setWhatsThis(sCompleted_id,"Do not hide actions that have been checked off");

   pCC_id = options->insertItem("Parent Completes Child", this,SLOT(sTogglePCC()));
   options->setItemChecked(pCC_id, false); //another preference
   options->setWhatsThis(pCC_id,"Checking a parent item automatically checks its children");

   cCP_id = options->insertItem("Child Completes Parent", this,SLOT(sToggleCCP()));
   options->setItemChecked(cCP_id, false); //another preference
   options->setWhatsThis(cCP_id,"Checking all child items automatically checks their parent");

   options->insertSeparator();
   options->insertSeparator();

   purge_id = options->insertItem("Purge Completed Actions", this, SLOT(sPurgeActions()));
   options->setWhatsThis(purge_id,"Permanently deletes all checked action items (no undelete).  Applies to children of a currently selected item, or all actions if no item is selected");
   options->setItemEnabled(purge_id,false);

   emptyT_id = options->insertItem("Empty trash",this,SLOT(sPurgeTrash()));
   options->setWhatsThis(emptyT_id,"Purges all deleted items");
   options->setItemEnabled(emptyT_id,false);

   // Create a help menu
   help = new QPopupMenu();
   help->insertItem("About Prozect", this, SLOT(sAboutProzect()));
   help->insertItem("General help",this,SLOT(sGenHelp()));
   help->insertItem("What's This? mode", this, SLOT(whatsThis()));
   help->insertItem("About Qt", this, SLOT(sAboutQt()));
   

   // Create a menubar
   toolBar2 = new QToolBar(this);
   toolBar2->setHorizontalStretchable(true);
   menu = new QMenuBar(toolBar2);
   //toolBar2 = new QToolBar(this);

   //menu = new QPEMenuBar(this);
   menu->insertItem("&Outline", file);
   menu->insertItem("&Options", options);
   menu->insertItem("&Help", help);

   toolBar2->addSeparator();
}

void Prozect::initialiseToolBar() {

  toolBar = new QToolBar( this, "tools");
  toolBar->setHorizontalStretchable(true);

  lineEdit = new QLineEdit(toolBar, "input");
  lineEdit->setMaximumWidth(95);
  //rDebug("lineEdit is %d wide",lineEdit->width());
  connect(lineEdit,SIGNAL(returnPressed()),this, SLOT(sDoLineEdit()));

  QWhatsThis::add(lineEdit,QString("Edit Window: enter text for a new item here, or modify an existing item.  Return (/) when finished"));


  btnLeft = new QToolButton(LeftArrow,toolBar);
  btnLeft->setAutoRepeat(false);
  connect(btnLeft,SIGNAL(clicked()), this, SLOT(sMoveNodeLeft()));
  QWhatsThis::add(btnLeft,"Move selected item left");

  btnUp = new QToolButton(UpArrow,toolBar);
  btnUp->setAutoRepeat(false);
  connect(btnUp,SIGNAL(clicked()), this, SLOT(sMoveNodeUp()));
  QWhatsThis::add(btnUp,"Move selected item up");

  btnDown = new QToolButton(DownArrow,toolBar);
  btnDown->setAutoRepeat(false);
  connect(btnDown,SIGNAL(clicked()), this, SLOT(sMoveNodeDown()));
  QWhatsThis::add(btnDown,"Move selected item down");

  btnRight = new QToolButton(RightArrow,toolBar);
  btnRight->setAutoRepeat(false);
  connect(btnRight,SIGNAL(clicked()), this, SLOT(sMoveNodeRight()));
  QWhatsThis::add(btnRight,"Move selected item right");


  itemTypes = new QStringList();

  // if change order of list, change slotSelectionChanged()!
  *itemTypes << "info" << "action" << "numeric" << "progress";

  cBoxItemTypes = new QComboBox(toolBar);
  cBoxItemTypes->setMaximumWidth(65);
  cBoxItemTypes->insertStringList(*itemTypes);
  QWhatsThis::add(cBoxItemTypes,"Set the type for a new or existing item");

  connect(cBoxItemTypes,SIGNAL(activated(const QString &)),this,SLOT(sNewItemType(const QString &)));

  //pixmap looks better on Z than in qvfb
  btnNew= new QToolButton(Resource::loadPixmap("new"),QString("new"),QString::null,
  			  this,SLOT(sNewBtn()), toolBar);
  btnNew->setMaximumWidth(15);
  QWhatsThis::add(btnNew,"New Item: clear any selected text, ready to enter a new item after the last selected one");

  btnDel= new QToolButton(Resource::loadPixmap( "trash" ),QString("del"),QString::null, 
  			  this,SLOT(sDeleteNode()), toolBar);
  btnDel->setMaximumWidth(15);
  QWhatsThis::add(btnDel,"Delete the selected item");

  btnDate = new DateButton(false, toolBar2, "date");
  connect(btnDate, SIGNAL(dateSelected(int,int,int)), this, SLOT(sAddDate(int, int, int)));
  btnDate->setMaximumWidth(90);
  btnDate->setDateFormat(TimeString::currentDateFormat());
  QWhatsThis::add(btnDate,"Add a due date to the selected item");

  btnDelDate= new QToolButton(Resource::loadPixmap( "editdelete" ),QString("delDate"),QString::null, 
  			  this,SLOT(sDelDate()), toolBar2);
  btnDelDate->setMaximumWidth(15);
  QWhatsThis::add(btnDelDate,"Delete the due date for the selected item");

}

// don't think these really have a place on Zaurus, but...
void Prozect::initialiseShortcuts() {
  file->setAccel(CTRL+Key_O, open_id);
  file->setAccel(CTRL+Key_S, save_id);
  
  btnNew->setAccel(CTRL+Key_N);
  btnDel->setAccel(CTRL+Key_D);
  //btnDelDate->setAccel(CTRL+Key_T);
}

void Prozect::initialiseNoteEdit() {
  qmle = new QMultiLineEdit(prozStack,"note editor");
  qmle->setWordWrap( QMultiLineEdit::WidgetWidth );
  showQMLE=false;
}

void Prozect::initialiseFileSelect() {
  fs = new FileSelector (MIMETYPE, prozStack, "file open",TRUE,FALSE);
  currDoc.setType(MIMETYPE);

  QObject::connect(fs, 
                   SIGNAL(closeMe()),  // won't happen with closeVisible=false
                   this, 
                   SLOT( sShowProzect()));  
  QObject::connect(fs, 
                   SIGNAL(newSelected( const DocLnk &)), 
                   this, 
                   SLOT( sNewOutline( const DocLnk &)));
  QObject::connect(fs, 
                   SIGNAL(fileSelected( const DocLnk &)), 
                   this, 
                   SLOT( setDocument( const DocLnk &)));
}


void Prozect::showFileSelect() {
  toolBar->hide();
  toolBar2->hide();
  fs->reread();
  prozStack->raiseWidget(fs);

}

void Prozect::showNoteEdit() {
  toolBar->hide();
  toolBar2->hide();
  prozStack->raiseWidget(qmle);
}

// explicit support for Numeric items, must get numerator and denominator
void Prozect::initialiseTextWidgets() {
  getNiNumDenW = new getNiNumDen(this,"Numeric Item Details",true);
  getNameW = new getNameD(this,"Name",true);
  getNoteW = new getNoteD(this,"Note",true);
}

void Prozect::ni_getNumDen(NumericItem *ni) {

  int tnum = ni->getNumerator();
  int tden = ni->getDenominator();

  if (getNiNumDenW->query(&tnum,&tden)) {
    ni->setNumerator(tnum);
    ni->setDenominator(tden);
  }

  ni->updateBar();
}



// file I/O interfaces

bool Prozect::saveTree() {

  TIMCHK("start saveTree");

  static QByteArray ba;
  ba.fill(0);

  QTextStream outstream(ba, IO_WriteOnly);

  saveOutlineTree(list->firstChild(), outstream);

  FileManager fm;

  currDoc.removeFiles();

  if (! fm.saveFile(currDoc,ba)) {
    printf("failed to write to %s\n",currDoc.file().latin1());
    return false;
  } 
  rDebug("finished saveFile name:%s file:%s ",currDoc.name().latin1(),currDoc.file().latin1());

  currDoc.removeLinkFile();
  is_clean = true;

  TIMCHK("finished saveTree");
  return true;
}

bool Prozect::checkForSave()
{

  if (is_clean) return true;
  if (options->isItemChecked(autosave_id)) {
    sSave();
    return is_clean;
  }

  QString query;

  if (currDoc.name().isEmpty())
    query = QString("Do you want to save changes to \n <untitled>?");
  else 
    query = QString("Do you want to save changes to \n %1?").arg(currDoc.name().latin1());

 cfs_retry:
   int ret = QMessageBox::critical(this, QString("Save changes"),
				   query,
				   QMessageBox::Yes | QMessageBox::Default,
				   QMessageBox::No,
				   QMessageBox::Cancel | QMessageBox::Escape);
   
   switch (ret) {
    case QMessageBox::Yes:
      sSave();
      if (! is_clean)
	goto cfs_retry;

      break;
    case QMessageBox::No:
      // do nothing
      is_clean=true;  // don't ask again
      break;
    default:
      return false;
      break;
   }
   return true;
}


void Prozect::loadFile() {
  if (currDoc.name().isEmpty()) 
    rDebug("enter loadFile new file");
  else
    rDebug("enter loadFile %s",currDoc.name().latin1());

  sPurgeTrash();

  list->clear();

  if (!loadTree(list,currDoc)) {
    return;  // can't seem to get back to sOpen() from here...
  }
  rDebug("tree loaded");

  renumberBranch();  // don't trust input numbers - might be hand edited
  is_clean = true;

  if (options->isItemChecked(numbering_id)) {
    setNumbering(true);
  } else {
    setNumbering(false);
  }

  updateCaption();
  lastSelected = selected = NULL;
}


bool Prozect::setFileName() {
  currDoc.setType(MIMETYPE);

  QString init = currDoc.name();
  QString title = QString("Save File Name");
  QString name = getNameW->query( title, init );

  if (name.isEmpty()) 
    return false;

  rDebug("getName returns %s",name.latin1());

  if ( name.findRev(".proz") == -1) 
    currDoc.setName(name+".proz");
  else 
    currDoc.setName(name);
      
  //  if (fm.exists(currDoc)) // sadly this instantiates the DocLnk and is always true!
  // however the DocLnk instantiation process will create an _<n> file if it does exist.

  return true;
}

void Prozect::setCurrDoc(const DocLnk &dl) {

  currDoc.setLinkFile(QString::null);
  currDoc.setType(MIMETYPE);

  currDoc.setName(dl.name());

  currDoc.setFile(dl.file());

  //rDebug("setCurrDoc: name= %s fknown= %d lfknown= %d",
  //	 currDoc.name().latin1(),currDoc.fileKnown(),currDoc.linkFileKnown());
}

// set the file name in the title bar
void Prozect::updateCaption() {
  QString s = currDoc.name();
  int ndx;

  if (s.isEmpty()) 
    s = "untitled";
  else 
    if ((ndx = s.findRev(".proz")) != -1) 
      s.truncate(ndx);

#ifdef DEMO
  setCaption( tr("Prozect-demo") + ": " + s );
#else
  setCaption( tr("Prozect") + ": " + s );
#endif
}

// save current configuration.  Used to be .prozectrc instead of QConfig, hence the name.
void Prozect::rcSave() {

  Config *prozConfig = new Config("prozect",Config::User);
  prozConfig->setGroup("prozGroup");

  prozConfig->writeEntry("numbering",options->isItemChecked(numbering_id));
  prozConfig->writeEntry("itemDate",options->isItemChecked(itemDate_id));
  prozConfig->writeEntry("age",options->isItemChecked(age_id));
  prozConfig->writeEntry("autosave",options->isItemChecked(autosave_id));
  prozConfig->writeEntry("showCompleted",options->isItemChecked(sCompleted_id));
  prozConfig->writeEntry("pcc",options->isItemChecked(pCC_id));
  prozConfig->writeEntry("ccp",options->isItemChecked(cCP_id));
  prozConfig->writeEntry("itemType",cBoxItemTypes->currentItem());
  prozConfig->writeEntry("col0",list->columnWidth(0));
  prozConfig->writeEntry("col1",list->columnWidth(1));
  prozConfig->writeEntry("col2",list->columnWidth(2));

  if ( ! currDoc.name().isEmpty() ) {
    prozConfig->writeEntry("file",currDoc.file());
  }

  delete prozConfig;
}

// re-load previous configuration options
void Prozect::rcLoad() {

  Config *prozConfig = new Config("prozect",Config::User);
  prozConfig->setGroup("prozGroup");

  options->setItemChecked(numbering_id,prozConfig->readBoolEntry("numbering",options->isItemChecked(numbering_id)));
  options->setItemChecked(itemDate_id,prozConfig->readBoolEntry("itemDate",options->isItemChecked(itemDate_id)));
  options->setItemChecked(age_id,prozConfig->readBoolEntry("age",options->isItemChecked(age_id)));
  options->setItemChecked(autosave_id,prozConfig->readBoolEntry("autosave",options->isItemChecked(autosave_id)));
  options->setItemChecked(sCompleted_id,prozConfig->readBoolEntry("showCompleted",options->isItemChecked(sCompleted_id)));
  options->setItemChecked(pCC_id,prozConfig->readBoolEntry("pcc",options->isItemChecked(pCC_id)));
  options->setItemChecked(cCP_id,prozConfig->readBoolEntry("ccp",options->isItemChecked(cCP_id)));
  cBoxItemTypes->setCurrentItem(prozConfig->readNumEntry("itemType",cBoxItemTypes->currentItem()));
  list->setColumnWidth(0,prozConfig->readNumEntry("col0",list->columnWidth(0)));
  list->setColumnWidth(1,prozConfig->readNumEntry("col1",list->columnWidth(1)));
  list->setColumnWidth(2,prozConfig->readNumEntry("col2",list->columnWidth(2)));
  
  QString file = prozConfig->readEntry("file",QString::null);
  if (! file.isEmpty()) 
    setDocument(file);

  delete prozConfig;
}

// add a new item to the list, optionally have it be selected.
// if selected, next action applies to this item, else next 
// action (e.g. input to LineEdit) will be for a new item
void Prozect::insertNode(bool keepSel=false) {

  if (lineEdit->text().isEmpty()) {
    rDebug("no text in lineEdit window");
    return;
  }

  OutlineItem *newNode;
  QString le_tref = lineEdit->text();
  QString cbit_tref = cBoxItemTypes->currentText();
  OutlineItem *lsp=NULL;
  int newNum;

  if (lastSelected) {
    rDebug("insertNode: ls= %d %s",lastSelected->getNumber(),lastSelected->text().latin1());

    lsp = lastSelected->parent();
    newNum = lastSelected->getNumber()+1;
    selected = newNode = getNode(cbit_tref,lsp,le_tref);

    makeHole(lastSelected->nextSibling(),newNum+1);
    newNode->setNumber(newNum);

    forceNumSort(true);
    if (lsp) {
      lsp->updateBar();
      lsp->sortChildItems(0,false);
      lsp->sortChildItems(0,true);
    } else {
      list->sort();
    }
    forceNumSort(false);

  } else 
    selected = newNode = getNode(cbit_tref,0,le_tref);

  lastSelected = selected;

  newNode->setNumbering(options->isItemChecked(numbering_id));
  newNode->edate = new QDate(QDate::currentDate());
  newNode->showItemAge(options->isItemChecked(age_id));

  list->ensureItemVisible(newNode);

  if (newNode->isNumeric()) 
    ni_getNumDen((NumericItem*)selected);


  if (!keepSel) {
    if (list->selectedItem()) {
      list->clearSelection();
    } else {
      selected=NULL;
      lineEdit->clear();
      lineEdit->setFocus();
    }
  } else {
    list->setSelected(selected,true);
  }

  is_clean = false;
}

// create and initialise a new item of the appropriate type.

OutlineItem * Prozect::getNode(const QString &type, OutlineItem *par, QString &text_ref) {
  if (par) {
    if (type == "info")
      return new OutlineItem(par,text_ref);
    else if (type == "action") 
      return new TodoItem(par,text_ref);
    else if (type == "progress") 
      return new ProgressItem(par,text_ref);
    else if (type == "numeric") 
      return new NumericItem(par,text_ref);
    else
      printf("getNode-oi: type %s not recognized\n",type.latin1());
  } else {
    if (type == "info")
      return new OutlineItem(list,text_ref);
    else if (type == "action") 
      return new TodoItem(list,text_ref);
    else if (type == "progress") 
      return new ProgressItem(list,text_ref);
    else if (type == "numeric") 
      return new NumericItem(list,text_ref);
    else
      printf("getNode-oi: type %s not recognized\n",type.latin1());
  }

  return NULL;

}

// as the name implies, move a node and its children under a new parent

OutlineItem* Prozect::moveSubTree(OutlineItem *parent, OutlineItem *node) {
  return moveSubTreeAct(0,parent,node);
}

OutlineItem* Prozect::moveSubTree(Outline *list, OutlineItem *node) {
  return moveSubTreeAct(list,0,node);
}

OutlineItem* Prozect::moveSubTreeAct(Outline *list, OutlineItem *parent, OutlineItem *node) {
  OutlineItem *new_node;
  
  QString text_ref = node->plainText(0);
  
  if (node->isTodo()) {

    if (parent) 
      new_node = new TodoItem(parent, text_ref);
    else
      new_node = new TodoItem(list, text_ref);

    if (node->isOn()) // need to keep onCount accurate
	new_node->setOn(true);
  } else if (node->isProgress()) {
    if (parent)
      new_node = new ProgressItem(parent, text_ref);
    else
      new_node = new ProgressItem(list, text_ref);

  } else if (node->isNumeric()) {
    NumericItem *nn;
    if (parent)
      nn = new NumericItem(parent, text_ref);
    else
      nn = new NumericItem(list, text_ref);

    NumericItem *n = (NumericItem*) node;
    nn->setDenominator(n->getDenominator());
    nn->setNumerator(n->getNumerator());
    new_node = nn;
  } else {
    //if (node->isOutline()) // default 
    if (parent) 
      new_node = new OutlineItem(parent,text_ref);
    else 
      new_node = new OutlineItem(list,text_ref);

  }

  replaceNode(new_node,node);

  if (parent) 
    renumberBranch(parent);
  else
    renumberBranch();

  return new_node;
}

// some change is required, create a new node, copy data from old, delete old
void Prozect::replaceNode(OutlineItem *dst, OutlineItem *src) {

  dst->setNumbering(options->isItemChecked(numbering_id));

  OutlineItem *oi = src->firstChild();
  while (oi) {
    OutlineItem *noi = oi->nextSibling();
    moveSubTree(dst,oi);
    oi = noi;
  }

  dst->replicate(src);

  src->ddate = NULL;
  src->edate = NULL;
  src->note = NULL;

  if (dst->note) 
    dst->setPixmap(Outline::noteCol,Resource::loadPixmap( "DocsIcon" ));
  else
    dst->setPixmap(Outline::noteCol,QPixmap::QPixmap());

  delete src;
}

// set the specified item and all subsequent siblings to count up from the passed item number.
// result is that a new item can be set to the (now unused) n-1 value, the list sorted, and have
// the new item at an arbitrary location
void Prozect::makeHole(OutlineItem *oi, int i) {
    while (oi) {
      oi->setNumber(i++);
      oi = oi->nextSibling();
    }
}

//sort numerically even if the current preference is for sort-by-date.  needed for various
// tree manipulations (e.g. insert)
void Prozect::forceNumSort(bool b) {
  if (b)
    list->dateSort(false);
  else if (options->isItemChecked(sortDate_id)) {
    list->dateSort(true);
    list->fullSort();
  }
}

// add text waiting in MultiLineEdit to the selected item, add a note icon too.
void Prozect::addNote() {

  if (!selected)
    return;

  if (getNoteW->query(selected->text(),selected->note,&(selected->note))) 
    is_clean=false;

  if (selected->note) 
    selected->setPixmap(Outline::noteCol,Resource::loadPixmap( "DocsIcon" ));
  else 
    selected->setPixmap(Outline::noteCol,QPixmap::QPixmap());


}

// set the date shown on the date button to the current date or the (entry or due) date
// of the currently selected item.
void Prozect::setBtnDate() {
  if (selected) {
    if (options->isItemChecked(itemDate_id)) {
      btnDate->setDate(*(selected->edate));
    } else {
      if (selected->ddate) 
	btnDate->setDate(*(selected->ddate));
      else
	btnDate->setDate(QDate::currentDate());
    }
  } else {
    btnDate->setDate(QDate::currentDate());
  }

}


// show/hide the item numbers on each line
void Prozect::setNumbering(bool numbering_on) {
  //options->setItemChecked(numbering_id, numbering_on);

  OutlineItem *node = list->firstChild();
  while (node) {
    node->setNumbering(numbering_on);
    node = node->nextSibling();
  }

  // qtopia bug ?  if the column is not wide enough to display the text
  // for a given item, the string is not re-drawn when the text is cahnged
  // (so the numbering remains on these items)
  //  QListViewItem::widthChanged() does not seem to help
  // workaround:  user must fmanually re-size columns

  list->triggerUpdate();

}

// reset the numbers for this branch of the outline to increment nicely
void Prozect::renumberBranch(OutlineItem *parent=0) {
  OutlineItem *node;

  if (parent) {
    parent->sortChildItems(0, false); 
    node = parent->firstChild();
  } else {
    list->sort();
    node = list->firstChild();
  }

  int i = 1;
  while (node) {
    //rDebug("renumber oi: (i= %d) %s (node-num= %d)",i,node->text(0).latin1(),node->getNumber());
    node->setNumber(i++);

    renumberBranch(node);

    node = node->nextSibling();
  }

  list->triggerUpdate();

  if (parent) 
    parent->updateBar();
}

// helper routine to set boolean state variable according to state of checked menu item.

bool Prozect::toggleItem(int id) {
  if (options->isItemChecked(id)) {
    options->setItemChecked(id, false);
    return false;
  } else {
    options->setItemChecked(id, true);
    return true;
  }
}

// re-implemented here so we can checkForSave(), and not drop all the
// way out if it is a close from e.g. the note editor window
void Prozect::closeEvent(QCloseEvent *e) {

  if (showQMLE) {
    addNote();
    return;
  }

  rDebug("close event");
  if (!checkForSave()) return;
  rDebug("doc save done");
  rcSave();
  rDebug("rcSave done");
  QMainWindow::closeEvent(e);
}

// re-implemented here so we can update the days-to column more effectively.  
// stil doesn't work if Prozect is on top when Zaurus is turned on, need to switch 
// to desktop or some other app and back again to get days correct.
void Prozect::paintEvent ( QPaintEvent *e ) {
  //rDebug("paintEvent!");
  if (!lastDCheck || lastDCheck->daysTo(QDate::currentDate())) {
    list->showItemAge(options->isItemChecked(age_id));
    delete lastDCheck;
    lastDCheck = new QDate(QDate::currentDate());
  }
  QWidget::paintEvent(e);
}












