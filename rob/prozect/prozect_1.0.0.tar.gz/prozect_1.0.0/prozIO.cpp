/*******************
 *
 *  prozIO.cpp
 *  
 *  basic I/O routines to read and save Prozect outlines.  
 *  enhanced emacs outline format.
 *
 *  This file is part of Prozect.
 *  Copyright (C) 2003 Robert T. Miller
 *  
 *  Prozect is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  Prozect is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with Prozect; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  
 ******************/

#include "Outline.h"
#include "OutlineItem.h"
#include "TodoItem.h"
#include "ProgressItem.h"
#include "NumericItem.h"

#include <qpe/applnk.h>
#include <qpe/filemanager.h>
#include <qtextcodec.h>
#include <qstringlist.h>
#include <stdlib.h>
#include <stream.h>
#include <ctype.h>
#include <qmessagebox.h>
#include <qpe/resource.h>

#include "debug.h"

// dump each item to passed output stream, using item's own output routine
static void walkTree(OutlineItem *node, QTextStream &out) {
  node->itemOutput(out);

  OutlineItem *nextOI = node->firstChild();
  if (nextOI) 
    walkTree(nextOI,out);

  nextOI = node->nextSibling();
  if (nextOI) {
    if (nextOI->depth() == 0) out << '\n';
    walkTree(nextOI,out);
  }
}

// walkTree() with emacs outline mode identifier at top
void saveOutlineTree(OutlineItem *node, QTextStream &out) {
  out << "-*- mode: outline -*-\n\n";
  walkTree(node,out);
}

// allocate new item of appropriate class, methods for Outline or OutlineItem level calls
static OutlineItem *newItem(bool is_todo, bool is_p, bool is_n, Outline *list, QString *it) {
  if (is_todo)
    return new TodoItem(list,*it);
  else if (is_p) 
    return new ProgressItem(list,*it);
  else if (is_n)
    return new NumericItem(list,*it);
  else
    return new OutlineItem(list,*it);
}

static OutlineItem *newItem(bool is_t, bool is_p, bool is_n, OutlineItem *last, QString *it) {
  if (is_t)
    return new TodoItem(last,*it);
  else if (is_p) 
    return new ProgressItem(last,*it);
  else if (is_n)
    return new NumericItem(last,*it);
  else
    return new OutlineItem(last,*it);
}

// read Prozect input file, generate data structure
bool loadTree(Outline *list, const DocLnk &f) {

  FileManager fm;
  QString txt;
  QByteArray ba;

  rDebug("entering loadTree: %s",f.name().latin1());

  if ( fm.loadFile( f, ba ) ) {
    txt = QString::fromUtf8(ba, ba.size());
    if ( txt.utf8().length() != ba.size() ) {
      // not UTF8
      QTextCodec* codec = QTextCodec::codecForContent(ba.data(),ba.size());
      if ( codec ) {
	txt = codec->toUnicode(ba);
      }
    }
  } else {
    printf("failed to load file %s\n",f.name().latin1());
    QMessageBox::about(0,"error loading file","could not load file "+f.name());
    return false;
  }

  //rDebug("past fm.loadfile\n txt=->%s<-",txt.latin1());

  QStringList qsl = QStringList::split("\n",txt,TRUE);
  int ndx(0);
  OutlineItem *last = NULL;
  QString body="";


  for ( QStringList::Iterator it = qsl.begin(); it != qsl.end(); ++it, ++ndx ) {
    bool is_completed = false;
    bool is_todo = false;
    bool is_progress = false;
    bool is_numeric = false;
    
    OutlineItem *current = NULL;
    QDate *itemDate = NULL;
    QDate *entryDate = NULL;
    int numer=0,denom=0;

    //if (!ndx) continue;  // skip mode line
    if ((*it).find(QString("-*- mode:")) > -1) {
      rDebug("skipping %s",(*it).latin1());
      continue;  //skip mode line if present
    }

    // have a line
    if (! (*it).isEmpty()) //( && strcmp((*it),"\n") )
      rDebug( "->%s<- ", (*it).latin1() );
    
    // scan for depth and process
    int depth = 0;
    
    while ((*it)[depth] == '*')
      depth++;
    
    if (depth) {  // have a heading line
      // so add any body we just read to last item

      if ( body.find(QRegExp("[^\\s]")) != -1) {  // have some text
	//body = body.simplifyWhiteSpace();
	rDebug("text body= ->%s<-",body.latin1());
	if (last != NULL) {
	  last->note = new QString(body);
	  last->setPixmap(Outline::noteCol,Resource::loadPixmap( "DocsIcon" ));
	} else {
	  rDebug("last is NULL");
	  last = newItem(false,false,false,list,&body);
	}
	rDebug("body inserted at depth %d",last->depth());
	body.truncate(0);
      }

      // remove depth chars
      int i=0;
      int num=0;
      (*it).remove(0,depth);

      //rDebug("depth is %d new string: ->%s<-",depth,(*it).latin1());
      depth--;  //match to QListView depths

      // scan for and process numbers

      if (isdigit((int) ((*it).latin1())[0])) {
       	num = atoi((*it).latin1());
	//while ((*it)[i++] != ' ');
	i=0;
	while (isdigit((int) ((*it).latin1())[i])) {
	  //rDebug("digit: .%c. i=%d",(*it).latin1()[i],i);
	  i++;
	}
	//rDebug("i=%d",i);
	(*it).remove(0,i);
      }

      // scan for and process progress/numeric/todo chars
      if ((*it)[0] == '[') {
	if ((*it)[1] == ']') {
	  (*it).remove(0,2);
	  is_progress = true;
	} else if ((*it)[1] == 'o') {
	  (*it).remove(0,3);
	  is_completed = false;
	  is_todo = true;
	} else if ((*it)[1] == '+') {
	  (*it).remove(0,3);
	  is_completed = true;
	  is_todo = true;
	} else {
	  if (sscanf((*it).latin1(),"[%d/%d]",&numer,&denom) == 2) 
	    is_numeric = true;
	  (*it).remove(0,(*it).find(']')+1);
	}
      }

      // scan for and process entry date
      if ((*it)[0] == '{') {
	int y,m,d;
	if (sscanf((*it).latin1(),"{%d/%d/%d}",&y,&m,&d) == 3) 
	  entryDate = new QDate(y,m,d);
	  (*it).remove(0,(*it).find('}')+1);
      }

      // scan for and process due date
      if ((*it)[0] == '<') {
	int y,m,d;
	if (sscanf((*it).latin1(),"<%d/%d/%d>",&y,&m,&d) == 3) 
	  itemDate = new QDate(y,m,d);
	  (*it).remove(0,(*it).find('>')+1);
      }

      (*it).remove(0,(*it).find(' ')+1);

      rDebug("depth= %d num= %d is_todo= %d is_completed= %d e-date= %s d-date= %s string= ->%s<-",
	     depth,num,is_todo,is_completed,
	     (entryDate ? entryDate->toString().latin1() : "-"),
	     (itemDate ? itemDate->toString().latin1() : "-"),(*it).latin1());

      if (last == NULL) {  
	current = newItem(is_todo,is_progress,is_numeric,list,&(*it));
	//rDebug("new top level item starting out");
      } else if (depth == 0) {  //last == NULL 
	while (last->depth() > depth) {
	  last = last->parent();
	}
	current = newItem(is_todo,is_progress,is_numeric,list, &(*it));
	//rDebug("new top level item because depth=0");
	//rDebug(" should be after [%s]",(last->qlvi->text(0)).latin1());
      } else if (last->depth() < depth) {
	current = newItem(is_todo,is_progress,is_numeric,last, &(*it));
	//rDebug("new item more deep (last= %d current= %d)",last->depth(),depth);
	//rDebug(" under [%s]",(last->qlvi->text(0)).latin1());
      } else if (last->depth() > depth) {
	//rDebug("new item less deep (last= %d current= %d)",last->depth(),depth);
	while (last->depth() > depth) {
	  last = last->parent();
	}
	current = newItem(is_todo,is_progress,is_numeric,last->parent(), &(*it));
	//rDebug(" should be after [%s]",(last->qlvi->text(0)).latin1());
      } else {
	current = newItem(is_todo,is_progress,is_numeric,last->parent(),&(*it));
	//rDebug("new item at same depth (last= %d current= %d)",last->depth(),depth);
	//rDebug(" should be after [%s]",(last->qlvi->text(0)).latin1());
      }

      if (is_todo) {
	if (is_completed) 
	  ((TodoItem*)current)->setOnSingle(is_completed);
	//rDebug("completed: %s",current->text().latin1());
      }

      if (is_numeric) {
	((NumericItem*)current)->setNumerator(numer);
	((NumericItem*)current)->setDenominator(denom);
	current->updateBar();
      }

      if (num) {
	current->setNumber(num);
	//rDebug("setNumber to %d",num);
      }

      if (itemDate) {
	current->ddate = itemDate;
	current->setText(Outline::dateCol,QString::number(QDate::currentDate().daysTo(*itemDate)));
      }


      if (entryDate) {
	current->edate = entryDate;
      } else {
	current->edate = new QDate(QDate::currentDate());  // to handle old style proz docs for now...
      }

      last = current;
      if (current->parent())
	current->parent()->updateBar();

      body.truncate(0);
    } else if (! (*it).isEmpty()) { // line does not start with *, must be text body
      body += *it;
      body += "\n";
    }
  }

  if ( body.find(QRegExp("[^\\s]")) != -1) {  // have some text
    //body = body.simplifyWhiteSpace();
    rDebug("final text body= ->%s<-",body.latin1());
    if (last != NULL) {
      last->note = new QString(body);
      last->setPixmap(Outline::noteCol,Resource::loadPixmap( "DocsIcon" ));
    } else {
      rDebug("last is NULL");
      last = newItem(false,false,false,list,&body);
    }
    rDebug("final body inserted at depth %d",last->depth());
    body.truncate(0);
  }
 
  return true;
}

