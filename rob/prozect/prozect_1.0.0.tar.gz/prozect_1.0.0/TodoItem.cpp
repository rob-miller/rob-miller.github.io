/**********************
 *
 * TodoItem.cpp
 *
 * function implementation for TodoItem class
 * 
 *  This file is part of Prozect.
 *  Copyright (C) 2003 Robert T. Miller
 *  
 *  Prozect is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  Prozect is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with Prozect; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  
 *********************/

#include "TodoItem.h"
#include "Outline.h"
#include "prozect.h"

#include "debug.h"

// constructor, called with Outline (QListView) as parent

TodoItem::TodoItem(Outline *list, QString &text) 
  : OutlineItem(list,text, FALSE) {

  rDebug("TodoItem constructor-o: entry %s",text.latin1());

  qlvi = (Qlvic*) qcli = new Qclic(list,text,this);  //QCheckListItem(list,text);

  list->mapOI[qlvi] = this;

  OutlineItem::isOutlineV = OutlineItem::isProgressV = OutlineItem::isNumericV = false;
  OutlineItem::isTodoV = true;

  OutlineItem::denInc=1.0;
  OutlineItem::value=0.0;
  
  checkState=0;
}

// constructor, called with OutlineItem (QListViewItem/QCheckListItem) as parent

TodoItem::TodoItem(OutlineItem *parent, QString &text) 
  :  OutlineItem(parent,text,FALSE) {

  rDebug("TodoItem constructor-oi: entry %s",text.latin1());

  qlvi = (Qlvic*) qcli = new Qclic(parent->qlvi,text,this);
  Outline *list = (Outline *) qcli->listView();
  list->mapOI[qlvi] = this;

  OutlineItem::isOutlineV = OutlineItem::isProgressV = OutlineItem::isNumericV = false;
  OutlineItem::isTodoV = true;

  OutlineItem::denInc=1.0;
  OutlineItem::value=0.0;

  checkState=0;
}

// destructor

TodoItem::~TodoItem() {
  rDebug("ti destructor called %s",this->text().latin1());
  
  //delete all children - depends on *qcli so ~OutlineItem cannot do it
  OutlineItem *coi = firstChild();
  while (coi) {
    rDebug("ti destroying child %s",coi->text(0).latin1());
    OutlineItem *noi = coi->nextSibling();
    delete coi;
    coi = noi;
  }
  

  Prozect *proz = listView()->getProz();
  if (isOn()) 
    proz->countOn(0);

  if (qcli) {
    listView()->mapOI[qcli] =NULL;  //how to delete the map entry ?
    delete qcli;
  }
  
  qlvi = NULL;
  qcli = NULL;

  rDebug("ti destructor finished");
}

// only for ToDoItem

// sets checkbox state, without checking parents or children
void TodoItem::setOnSingle(bool on)  // only for loadTree()
{
  //rDebug("setOn-single called");
  qcli->setOn(on);
  checkState = on;
  OutlineItem::value= (on ? 1.0 : 0.0);

  Prozect *proz = listView()->getProz();
  proz->countOn(on);

  OutlineItem *par = parent();
  if (par) {
    par->updateBar();
  }
}

// synchronises QCheckListItem checked state with private state variable checkState

bool TodoItem::updateCheckBox() {  // returns true if changed
  //rDebug("ucb: isOn= %d  checkstate= %d ",isOn(),checkState);
  if (checkState != isOn()) {
    setOn(isOn());
    return true;
  }
  return false;
}

// re-implemented from OutlineItem (access QCheckListItem instead of QListViewItem):

// return the OutlineItem for which the passed Q*CheckList*Item is a member
OutlineItem * TodoItem::mapToOI(QListViewItem *qcli) {
  //rDebug("enter mapToOI");
  if (qcli == NULL) {
    //rDebug("mapToOI-todoItem: qcli is NULL!");
    return NULL;
  }
  return listView()->mapOI[qcli];
}

void TodoItem::itemOutput(QTextStream& out) {
  out << this;
}

// access functions for class numbered

int TodoItem::getNumber() const {
  return qcli->getNumber();
}

void TodoItem::setNumber(int n) {
  qcli->setNumber(n);
}

bool TodoItem::getNumbering() {
  return qcli->getNumbering();
}


void TodoItem::setNumbering(bool b) {
  //rDebug("ti setNumbering(%d) %s",b,text().latin1());
  qcli->setNumbering(b);
  qcli->widthChanged();
  qcli->repaint();
  OutlineItem *oi = firstChild();
  while(oi) {
    oi->setNumbering(b);
    oi = oi->nextSibling();
  }
}

QString TodoItem::getNumberFormatted() {
  return qcli->getNumberFormatted();
}


// re-implemented from QListView and/or QCheckListItem

int TodoItem::depth() const {
  return qcli->depth();
}

int TodoItem::childCount() const {
  return qcli->childCount();
}

bool TodoItem::isOpen() {
  return qcli->isOpen();
}

void TodoItem::setOpen(bool o) {
  qcli->setOpen(o);
}

bool TodoItem::isOn() {
  return qcli->isOn();
}

// extra work for setOn() to handle child-completes-parent and parent-completes-child
void TodoItem::setOn(bool on) {
  //rDebug("setOn called");

  Prozect *proz = listView()->getProz();

  //rDebug("setOn isOn= %d  checkstate= %d  on= %d",isOn(),checkState,on);

  if (checkState != on) 
    proz->countOn(on);

  qcli->setOn(on);
  checkState = on;
  OutlineItem::value= (on ? 1.0 : 0.0);

  bool ccp = proz->ccp();
  bool pcc = proz->pcc();
  bool sci = proz->sct();


  OutlineItem * par = parent();

  if (par) 
    par->updateBar();

  if (on && pcc) {  // parent completes child
    // propogate "on" downward
    OutlineItem *child = firstChild();
    while (child) {
      child->setOn(on); 
      child = child->nextSibling();
    }

    rDebug("sct-oi %s: finished pcc",text().latin1());
  } 

  if (ccp)  { // child completes parent
    if (par && par->isTodo()) {  // and we have todo parent
      if (on && ! par->isOn()) {  // and we are on but parent is not
	// propagate "on" upward if siblings completed

	if (par->kidsCompleted())
	  par->setOn(true); 

      } else if (!on && par->isOn()) { // we are off but parent is on
	// propogate "off" upward

	if (par->isOn()) 
	  par->setOn(false);
      }
    } 

    rDebug("sct-oi %s: finished ccp",text().latin1());
  }

  rDebug("on=%d sci=%d isVis=%d",on,sci,isVisible());

  if (on && !sci && isVisible()) {  // may need to hide tree

    rDebug("sct-oi %s: hide tree? ",text().latin1());
    rDebug("par=%d isTodo= %d",(int) par, (((int) par) ? par->isTodo() : (int) par));
    rDebug("par=%d isOn= %d",(int) par, (((int) par) ? par->isOn() : (int) par));
    rDebug("par=%d kidsComp= %d",(int) par, (((int) par) ? par->kidsCompleted() : (int) par));

    if ( (!ccp && !pcc)        // if not child-completes-parent or parent-completes-child
	 || (ccp && (!par || !par->isTodo() || !par->kidsCompleted() ))  // or is ccp and parent won't change
	 || (pcc && (!par || !par->isOn()))    // or is pcc and parent is off
	 ) {  
      rDebug("sct-oi %s: yes, hide parental tree",text().latin1());
      proz->clearSelection();
      if (par) {
	rDebug("setOn %s calling showCompletedTodos for parent %s",text().latin1(),par->text().latin1());
	par->showCompletedTodos(false);
      } else {
	rDebug("setOn %s calling showCompletedTodos for list (top)",text().latin1());
	listView()->showCompletedTodos(false);
      }
    } else {
      rDebug("no, don't hide tree");
    }
  }

  rDebug("finished setOn %s",text().latin1());

} // setOn()


bool TodoItem::isSelected() {
  return qcli->isSelected();
}

OutlineItem * TodoItem::parent() {
  return (qcli ? mapToOI(qcli->parent()) : NULL);
}

OutlineItem * TodoItem::firstChild() {
  return (qcli ? mapToOI(qcli->firstChild()) : NULL);
}

OutlineItem * TodoItem::nextSibling() {
  return (qcli ? mapToOI(qcli->nextSibling()) : NULL);
}

OutlineItem * TodoItem::itemAbove() {
  return mapToOI(qcli->itemAbove());
}

OutlineItem * TodoItem::itemBelow() {
  return mapToOI(qcli->itemBelow());
}



void TodoItem::insertItem(OutlineItem *oi) {
  qcli->insertItem(oi->getItem());
  oi->setVisible(true);
}

void TodoItem::takeItem(OutlineItem *oi) {
  oi->setVisible(false);
  qcli->takeItem(oi->getItem());
}

QListViewItem * TodoItem::getItem() {
  return qcli;
}

Outline * TodoItem::listView() {
  return (Outline *) qcli->listView();
}



void TodoItem::sortChildItems(int i, bool b) {
  qcli->sortChildItems(i,b);
}

void TodoItem::setPixmap( int column, const QPixmap & pm ) {
  qcli->setPixmap( column, pm );
}

QString TodoItem::text(int col=0) const {
  return qcli->text(col);
}

void TodoItem::setText(int col, const QString &newText) {
  qcli->setText(col,newText);
}

QString TodoItem::plainText(int column=0) const {
  return qcli->plainText(column);
}



// private member functions

QTextStream& operator<<(QTextStream &out, TodoItem* node) {

  //  return out << (OutlineItem*) node;
  
  for (int i = 0; i <= node->depth(); i++) {
    out << '*';
  }
  //  out << node->getNumber();

  if (node->isOn()) 
    out << "[+]";
  else 
    out << "[o]";

  if (node->edate) {
    QDate *d = node->edate;
    out << '{' << d->year() << '/' << d->month() << '/' << d->day()  << '}';
  }

  if (node->ddate) {
    QDate *d = node->ddate;
    out << '<' << d->year() << '/' << d->month() << '/' << d->day()  << '>';
  }

  out << ' ' << node->plainText(0) << '\n';

  if (node->note)
    out << *(node->note) << '\n';

  return out;
}


