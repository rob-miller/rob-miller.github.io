/*
 *  Prozect.h
 *  Copyright (C) 2003 Robert T. Miller
 *
 *  This file is part of Prozect.
 *  
 *  Prozect is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  Prozect is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with Prozect; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  
 *  Prozect was originally based on ZOutline, copyright (C) 2002 Serge Stinkwich
 */

#ifndef PROZECT_H
#define PROZECT_H

#include <qwidget.h>
#include <qwidgetstack.h>
#include <qmainwindow.h>
#include <qpushbutton.h>
#include <qpopupmenu.h>
#include <qlistview.h>
#include <qfiledialog.h>
#include <qpe/qpemenubar.h>
#include <qpe/fileselector.h>

#include <qtoolbar.h>
#include <qlineedit.h>
#include <qcombobox.h>
#include <qmultilineedit.h>
#include <qaction.h>
#include <qpe/datebookmonth.h>
#include <qpoint.h>

#include "Outline.h"
#include "version.h"
#include "gNameD.h"
#include "gNiNumDen.h"
#include "gNote.h"

class QWidgetStack;
class NumericItem;

class Prozect : public QMainWindow
{
   Q_OBJECT

 public:
   Prozect(QWidget * parent = 0, const char * name = 0, WFlags f = WType_TopLevel);
   ~Prozect();

   void clearSelection();
   void countOn(bool on);
   bool sct();
   bool ccp();
   bool pcc();
   
 public slots:
   // Outline menu
   void sOpen();
   void sSave();
   void sUnDeleteNode();
   void sQuit();

   // Options menu
   void sToggleNumbering();
   void sToggleItemDate();
   void sToggleAge();
   void sToggleSortDate();
   void sAutosave();
   void sToggleShowCompleted();
   void sTogglePCC();
   void sToggleCCP();
   void sPurgeActions();
   void sPurgeTrash();

   // Help menu
   void sAboutProzect();
   void sGenHelp();
   void sAboutQt();

   // menu bar buttons (date stuff)
   void sAddDate(int,int,int);
   void sDelDate();

   // tool bar
   void sDoLineEdit();
   void sMoveNodeLeft();
   void sMoveNodeUp();
   void sMoveNodeDown();
   void sMoveNodeRight();
   void sNewItemType(const QString &);
   void sNewBtn();
   void sDeleteNode();

   // QlistView column actions
   void sSelectionChanged();
   void sItemClicked(QListViewItem *sel,const QPoint &qp,int col);

   // FileSelect widget actions
   void sShowProzect();
   bool sNewOutline();
   bool sNewOutline(const DocLnk &);
   void setDocument( const QString& applnk_filename );
   void setDocument( const DocLnk& dl );

 private:
   // routines

   void initialiseMenu();
   void initialiseToolBar();
   void initialiseShortcuts();
   void initialiseNoteEdit();
   void initialiseFileSelect();

   void showFileSelect();
   void showNoteEdit();

   //support for NumericItem getNumDen()
   void initialiseTextWidgets();
   void ni_getNumDen(NumericItem *);

   bool saveTree();
   bool checkForSave();
   void loadFile();
   bool setFileName();
   void setCurrDoc(const DocLnk &);
   void updateCaption();

   void rcSave();
   void rcLoad();

   void insertNode(bool keepSel=false);
   OutlineItem* getNode(const QString &,OutlineItem *, QString &);

   OutlineItem* moveSubTree(Outline*, OutlineItem*);
   OutlineItem* moveSubTree(OutlineItem*, OutlineItem*);
   OutlineItem* moveSubTreeAct(Outline*, OutlineItem*, OutlineItem*);
   void replaceNode(OutlineItem *dst, OutlineItem *src);
   void makeHole(OutlineItem *, int);
   void forceNumSort(bool);

   void addNote();
   void setBtnDate();

   void setNumbering(bool);
   void renumberBranch(OutlineItem *first=0);

   bool toggleItem(int item);

   // re-implemented Qtopia routines

   void closeEvent(QCloseEvent *);
   virtual void paintEvent ( QPaintEvent * );

 private:
   // variables

   QWidgetStack *prozStack;

   // prozect main GUI elements
   //  -- menu bar
   QMenuBar  *menu;
   QPopupMenu  *file, *help, *options;
   QToolButton *btnDelDate;
   DateButton *btnDate;

   //  -- tool bar
   QToolBar *toolBar;
   QToolBar *toolBar2;
   QToolBar *mbh;

   QLineEdit *lineEdit;
   QToolButton *btnLeft;
   QToolButton *btnRight;
   QToolButton *btnUp;
   QToolButton *btnDown;
   QToolButton *btnNew;
   QToolButton *btnDel;
   QStringList *itemTypes;
   QComboBox *cBoxItemTypes;

   // current outline elements
   DocLnk currDoc;
   Outline   *list;
   OutlineItem *selected;
   OutlineItem *lastSelected;

   // Qtopia sub-GUIs
   QMultiLineEdit *qmle;
   FileSelector *fs;

   // local sub-GUIs
   getNameD *getNameW;
   getNiNumDen *getNiNumDenW;
   getNoteD *getNoteW;

   // TrashCan
   stack<OutlineItem*> trashStack;

   // internal state variables
   bool is_clean;
   bool showQMLE;
   int onCount;
   QDate *lastDCheck;

   // menu, button IDs
   int new_id;
   int save_id;
   int exit_id;
   int saveas_id;
   int open_id;
   int numbering_id;
   int autosave_id;
   int itemDate_id;
   int age_id;
   int sortDate_id;
   int hide_id;
   int sCompleted_id;
   int pCC_id;
   int cCP_id;
   int purge_id;
   int emptyT_id;
   int undel_id;
};

#endif
