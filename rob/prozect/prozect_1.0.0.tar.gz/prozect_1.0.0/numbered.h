/**
 * numbered.h
 * original author Serge Stinkwich, copyright (C) 2002 Serge Stinkwich
 *
 *  The basic functionality of numbering nodes, factored out.
 *
 *  This file is part of Prozect.
 *  Copyright (C) 2003 Robert T. Miller
 *  
 *  Prozect is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  Prozect is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with Prozect; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  
*/
#ifndef H_NUMBERED
#define H_NUMBERED

class Numbered
{
private:
  int number;
  
public:
  virtual int getNumber() const;
  virtual void setNumber(int num);

};

#endif
