/**********************
 *
 * Outline.cpp
 *
 * function implementation for Outline class
 *
 *  This file is part of Prozect.
 *  Copyright (C) 2003 Robert T. Miller
 *  
 *  Prozect is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  Prozect is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with Prozect; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  
 *********************/

#include "Outline.h"

#include "OutlineItem.h"
#include "debug.h"
#include "prozect.h"

// constructor
Outline::Outline(Prozect *main, QWidget *parent, const char *name) 
  : QListView(parent, name), topLevel(main) {

  QListView::setShowSortIndicator(true);
  QListView::setRootIsDecorated(true);
  QListView::setMultiSelection(false);

  dateSortVal=0;
}

// destructor
Outline::~Outline() {
  if (Outline::firstChild())
    Outline::firstChild()->treeDelete();
}

// sorts all children as well as current level
void Outline::fullSort() {
  OutlineItem *oi = firstChild();
  while (oi) {
    oi->sortChildItems(1,true);
    oi = oi->nextSibling();
  }
  sort();
}

// link to top-level GUI so it can track number of completed todos 
Prozect * Outline::getProz() {
  return topLevel;
}

// trash stores deleted items in case user made a mistake
void Outline::trash(OutlineItem *oi) {
  rDebug("oi trash %s",oi->text().latin1());
  trashCan.push(oi);
  takeItem(oi);
}

void Outline::unTrash() {
  if (trashCan.size()>0) {
    rDebug("o unTrashing item %s",trashCan.top()->text().latin1());
    insertItem(trashCan.top());
    trashCan.pop();
  }
}

void Outline::emptyTrash() {
  OutlineItem *oi;

  while (trashCan.size()>0) {
    oi = trashCan.top();
    rDebug("o purging item %s",oi->text().latin1());
    insertItem(oi);
    delete (oi);
    trashCan.pop();
  }

  oi = firstChild();

  while (oi) {
    oi->emptyTrash();
    oi = oi->nextSibling();
  }
}

// routines for / relevant to item dates
void Outline::showItemAge(bool on) {
  OutlineItem *oi = firstChild();

  while (oi) {
    oi->showItemAge(on);
    oi = oi->nextSibling();
  }
}

bool Outline::dateSort() {
  return dateSortVal;
}

bool Outline::dateSort(bool b) {
  return (dateSortVal=b);
}

// Todo item support routines
void Outline::showCompletedTodos(bool state) {

  OutlineItem *oi;

  if (state) {  // show any hidden ones
    if (hidden.size()) 
      rDebug("unhiding %d items",hidden.size());
    while (hidden.size()>0) {
      rDebug("o unhiding item %s",hidden.top()->text().latin1());
      insertItem(hidden.top());
      hidden.pop();
    }

    oi  = firstChild();
    if (oi)
      oi->showCompletedTodos(state);

  } else { // hide any completed ones
    //rDebug("sct-o: hide");

    oi  = firstChild();
    while(oi) {

      if (oi->isOn()) { // only completed Todos have this
	rDebug("hide %s",oi->text().latin1());
	hidden.push(oi);
	OutlineItem *noi = oi->nextSibling();
	takeItem(oi);
	oi = noi;
      } else { // not completed or not a Todo, check children
	oi->showCompletedTodos(state);
	oi = oi->nextSibling();
      }
    }
  }

  rDebug("leaving sct-o");
}

void Outline::purgeActions() {
  OutlineItem *oi = firstChild();
  OutlineItem *noi;
  while (oi) {
    noi = oi->nextSibling();
    if (oi->isOn())
      delete oi;
    else {
      oi->purgeActions();
      oi->updateBar();
    }
    oi = noi;
  }
}

bool Outline::haveCompletedActions() {

  OutlineItem *oi = firstChild();
  while (oi) {
    if (oi->isOn())
      return true;
    else if (oi->hOICount() >0)
      return true;
    else if (oi->haveCompletedActions())
      return true;
    else
      oi = oi->nextSibling();
  }
  return false;
}


// routines re-implemented from QListView

OutlineItem * Outline::firstChild() {
  return mapOI[QListView::firstChild()];
}

OutlineItem * Outline::currentItem() {
  return mapOI[QListView::currentItem()];
}

OutlineItem * Outline::selectedItem() {
  return mapOI[QListView::selectedItem()];
}

void Outline::ensureItemVisible(OutlineItem *oi) {
  QListView::ensureItemVisible(oi->qlvi);
}

void Outline::setSelected(OutlineItem *oi, bool v) {
  QListView::setSelected(oi->qlvi,v);
}

void Outline::setCurrentItem(OutlineItem *oi) {
  QListView::setCurrentItem(oi->qlvi);
}

void Outline::setOpen(OutlineItem *oi, bool o) {
  QListView::setOpen(oi->qlvi,o);
}

void Outline::clear() {
  OutlineItem *fc;
  fc = Outline::firstChild();
  if (fc) 
    fc->treeDelete();
}

void Outline::insertItem(OutlineItem *oi) {
  QListView::insertItem(oi->getItem());
  oi->setVisible(true);
}

void Outline::takeItem(OutlineItem *oi) {
  oi->setVisible(false);
  QListView::takeItem(oi->getItem());
}


