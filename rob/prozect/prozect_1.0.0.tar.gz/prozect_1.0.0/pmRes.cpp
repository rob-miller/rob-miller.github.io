/*********************
 *  
 * pmRes.cpp
 *
 *  routines to generate a progress or completion bar
 *
 *  This file is part of Prozect.
 *  Copyright (C) 2003 Robert T. Miller
 *  
 *  Prozect is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  Prozect is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with Prozect; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  
 ********************/
#include "pmRes.h"
#include "bar_xpm1.h"
#include "bar_xpm2.h"

pmResource::pmResource() {
}

pmResource::~pmResource() {
}

QPixmap * pmResource::getPmA(int i) {
  switch(i) {
  case 0:
    return new QPixmap(bar0a);
  case 1:
    return new QPixmap(bar1a);
  case 2:
    return new QPixmap(bar2a);
  case 3:
    return new QPixmap(bar3a);
  case 4:
    return new QPixmap(bar4a);
  case 5:
    return new QPixmap(bar5a);
  case 6:
    return new QPixmap(bar6a);
  case 7:
    return new QPixmap(bar7a);
  case 8:
    return new QPixmap(bar8a);
  case 9:
    return new QPixmap(bar9a);
  default:
    return new QPixmap(bar10a);
  }
}

QPixmap * pmResource::getPmFracA(float val) {
  float rslt = val * 10.0;

  if (int(rslt) == int(rslt+0.5))
    return getPmA(int(rslt));
  else
    return getPmA(int(rslt+0.5));
}

QPixmap * pmResource::getPmB(int i) {
  switch(i) {
  case 0:
    return new QPixmap(bar0b);
  case 1:
    return new QPixmap(bar1b);
  case 2:
    return new QPixmap(bar2b);
  case 3:
    return new QPixmap(bar3b);
  case 4:
    return new QPixmap(bar4b);
  case 5:
    return new QPixmap(bar5b);
  case 6:
    return new QPixmap(bar6b);
  case 7:
    return new QPixmap(bar7b);
  case 8:
    return new QPixmap(bar8b);
  case 9:
    return new QPixmap(bar9b);
  default:
    return new QPixmap(bar10b);
  }
}

QPixmap * pmResource::getPmFracB(float val) {
  float rslt = val * 10.0;
  //int r = (int) roundf(rslt);
  if (int(rslt) == int(rslt+0.5))
    return getPmB(int(rslt));
  else
    return getPmB(int(rslt+0.5));
}

