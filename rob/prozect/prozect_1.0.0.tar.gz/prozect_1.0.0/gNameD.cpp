/*****************
 * gNameD.cpp
 *
 * dialogue to get text string name, because not universally supported
 * across Zaurus OSs.
 *
 *  This file is part of Prozect.
 *  Copyright (C) 2003 Robert T. Miller
 *  
 *  Prozect is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  Prozect is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with Prozect; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  
 ***************/

#include "moc_gNameD.cpp"

//#include "debug.h"

getNameD::getNameD(QWidget * parent=0, const char * name=0, bool modal=false, WFlags f=0 ) 
  : QDialog(parent, name, modal, f) {
  
  name_tb = new QToolBar("nameTB",(QMainWindow*)parent,this);
  name_le = new QLineEdit(name_tb,"nameLE");

  connect(name_le, SIGNAL(returnPressed()),this,SLOT(handleLERtn()));
}

getNameD::~getNameD() {
  delete name_le;
  delete name_tb;
}

QString getNameD::query(const QString &title, const QString &initName) {
  name_le->setText(initName);
  name_le->setFocus();
  setCaption(title);

  if (exec()) {
    //rDebug("getName returning .%s.",name_le->text().latin1());
    return name_le->text();
  } else 
    return QString::null;
}

void getNameD::handleLERtn() {
  accept();
}
  
