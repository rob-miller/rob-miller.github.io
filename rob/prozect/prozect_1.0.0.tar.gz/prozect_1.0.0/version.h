#define VERSION "1.0.1"
#define BUILDTIME "Wed Dec 10 09:28:22 2003 GMT"
