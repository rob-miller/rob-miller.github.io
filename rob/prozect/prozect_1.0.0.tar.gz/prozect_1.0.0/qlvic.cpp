/**********************
 *
 *  qlvic.cpp
 *  container class for QListViewItem to support outline with both ListViewItems and CheckListItems
 *  mainly required for sort() and inheritance of class numbered
 *
 *  This file is part of Prozect.
 *  Copyright (C) 2003 Robert T. Miller
 *  
 *  Prozect is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  Prozect is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with Prozect; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  
 *********************/
#include "numbered.h"
#include "qlvic.h"
#include "OutlineItem.h"
#include "debug.h"

Qlvic::Qlvic(QListView *list, QString &txt, OutlineItem *oi) 
  : QListViewItem(list,txt), myOI(oi) {

  setNumber(list->childCount());
  numbering=false;
}

Qlvic::Qlvic(QListViewItem *parent, QString &txt, OutlineItem *oi) 
  : QListViewItem(parent,txt), myOI(oi) {

  setNumber(parent->childCount());
  numbering=false;
}

Qlvic::~Qlvic() {
  rDebug("qlvic destructor called %s",text(0).latin1());
}

QString Qlvic::text(int column) const {
   if ((column != 0) || (numbering == false)) {
     return QListViewItem::text(column);
   } else {
      QString text("%1 %2");
      return text.arg(getNumberFormatted()).arg(QListViewItem::text(0));
   }
}

QString Qlvic::plainText(int column) const {
  return QListViewItem::text(column);
}


QString Qlvic::key(int, bool) const {
  QString tmp;
  if (myOI->dateSort()) {
    if (myOI->eDate()) 
      tmp.sprintf("%08d",-QDate::currentDate().daysTo(*(myOI->edate)));
    else if (myOI->ddate) 
      tmp.sprintf("%08d",QDate::currentDate().daysTo(*(myOI->ddate)));
    else 
      tmp.sprintf("%08d",getNumber()*100);
  } else {
    tmp.sprintf("%08d",getNumber());
  }
  return tmp;
}

bool Qlvic::getNumbering() {
  return numbering;
}

void Qlvic::setNumbering(bool on) {
  //rDebug("enter qlvic setNumbering bool: %d s: %s",on,text(0).latin1());
  numbering = on;
}

QString Qlvic::getNumberFormatted() const {
  OutlineItem *myParent = myOI->parent();
   if (myParent) {
      QString text("%1%2.");
      return text.arg(myParent->getNumberFormatted()).arg(getNumber());
   } else {
      QString text("%1.");
      return text.arg(getNumber());
   }
}

