/**********************
 *
 *  qlvic.h
 *  container class for QListViewItem to support outline with both ListViewItems and CheckListItems
 *  mainly required for sort() and inheritance of class numbered
 *
 *  This file is part of Prozect.
 *  Copyright (C) 2003 Robert T. Miller
 *  
 *  Prozect is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  Prozect is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with Prozect; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *  
 *********************/

#ifndef QLVIC_H
#define QLVIC_H

#include "numbered.h"
#include <qlistview.h>
#include <qstring.h>

class OutlineItem;

class Qlvic : public QListViewItem, public Numbered {
 public:
  Qlvic(QListView *, QString &, OutlineItem *);
  Qlvic(QListViewItem *, QString &, OutlineItem *);
  ~Qlvic();
  virtual QString text(int) const;
  virtual QString plainText(int) const;
  virtual QString key(int, bool) const;
  virtual bool getNumbering();
  virtual void setNumbering(bool);
  virtual QString getNumberFormatted() const;
 private:
  bool numbering;
  OutlineItem *myOI;
};

#endif
